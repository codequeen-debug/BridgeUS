# Blackstone Bridge

*ShellHacks submission, Blackstone challenge: reimagining how investors understand what they own and research what's next.*

**Education, not manipulation. An application for generations.**

> **Blackstone already teaches. Bridge lets you check.**

## The idea: an investment label with receipts
Blackstone already publishes education (Blackstone University). What no issuer can credibly
offer is an *independent* way to check the fine print. Bridge's core feature, **Check it**,
turns any fund document, fact sheet, quarterly report or social-media pitch into a one-page
**investment label**:

- **Cost on your amount, in dollars:** upfront charge, each yearly fee, performance fee, and
  early-sale penalty. Also shows fees over 10 years compared with a 0.03% index fund.
- **Getting your money out:** a 4-step access meter plus the exact withdrawal rules.
- **What you'd own, how the price is set, and what could go wrong.**
- **Red flags** (guaranteed returns, urgency, crypto or gift-card payment, pay-to-withdraw).
- **"Does the document answer the basics?"**: a score out of 6, plus what's *missing*
  (for example, "how big the early-sale penalty is").
- **Receipts:** every line has a numbered receipt. Tap it to highlight the exact sentence
  in the document.
- **Compare** up to 3 labels side by side.

**Why judges and Blackstone can trust it:**
1. **Receipts are verified in the browser.** Every AI quote is matched word-for-word against
   the pasted document. Anything that doesn't match is flagged "!", never silently shown.
2. **The AI never does arithmetic.** It only extracts stated percentages; every dollar figure
   is computed in code.
3. **It uses only the document.** The AI is told not to use outside knowledge, so the label
   reflects what the investor was actually shown.

**Who it's for:** Gen Z and young millennials who don't invest yet. Gallup finds only 44% of
adults under 30 own stock (vs. 72% of 50–64-year-olds), and the FTC finds people in their
20s report losing money to fraud more often than any other age.

## 60-second demo script
1. **Home:** "Read the fine print in 30 seconds." Point at the BREIT mini-label: $65
   first-year cost on $1,000, and $602 of fees over 10 years vs $6 for an index fund.
2. **Check it → Blackstone BXPE:** the label scores 5 of 6 and flags "Selling early: yes,
   amount not stated, ask how much." Tap a receipt and the source sentence lights up.
3. **Social media pitch:** 6 red flags, 1 of 6 basics answered.
4. **Paste real text live** (e.g. the fee section of a prospectus from SEC EDGAR). The AI
   builds a label, and the status line reports "N of N receipts found word-for-word."
5. **Compare:** BREIT vs the index fund, then change the amount to $10,000.
6. **Chat:** "Ask about this label" answers questions using the label's data.

## Also included
- **Start small:** see what $5–$50 a week became across every past stretch since 1928
  (worst, typical and best outcomes, plus the cost of waiting).
- **My portfolio:** holdings, access, real performance history, risk signals, and AI explanations.
- **Research:** compare asset classes and test "what if I added this?", plus a returns heatmap.
- **Learn, Stay safe, Money out:** short lessons, scam practice, and withdrawal-limit
  explainers (the real 2022–24 BREIT story).

**Design:**
- **Violet-blue:** trust.
- **Mint:** growth.
- **Sunny yellow:** optimism.
- **Ink indigo:** grounding.
- **Coral:** losses and warnings only.

## Run it
```
pip install -r requirements.txt
python app.py              # http://127.0.0.1:5000
python build.py            # single self-contained file: dist/blackstone-bridge.html
```

## How it answers the challenge

| Challenge ask | Where in Bridge |
|---|---|
| **Analyze existing portfolio** | *My portfolio*: edit holdings (or pick a sample mix). See total value, **money you could reach within a week**, 20-year average growth and worst year, and **fees in dollars**. |
| **Visualize performance** | *My portfolio*: your current mix replayed over 5–30 years of real returns vs. all-stocks, plus best/worst year, losing years and biggest drop. Every chart has "Show the numbers". |
| **Discover trends & risks** | Plain-English **signals** computed from your mix plus live conditions: concentration, withdrawal limits (private funds), rising rates vs. your bonds, cash vs. 3.4% inflation, hot streaks, fee drag. *Home* shows "What's happening now, and what it means for you". *Research* has a 10-year "who led each year" heatmap. |
| **Compare opportunities** | *Research*: pick up to 3 of 7 asset classes over 5 years to 98 years. See a growth chart, a stats table, and when you can get your money back. |
| **Evaluate what to invest in next** | *Research → What if I added this?*: shows the before/after change to growth, worst year, access and stock share for your own portfolio. |
| **Summarize complex information (filings, reports)** | *Check it*: any document becomes an investment label with verified receipts, dollar costs, and missing-info flags. |
| **Summarize complex information** | AI buttons: "Explain my portfolio in plain English" and "Explain this comparison". Both are grounded only in the numbers on screen. |
| **Ask questions in natural language** | "Chat with my investor" (bottom-right, every page). When published on claude.ai it uses Claude with your portfolio + dataset as context, plus page tools (`what_if_add`, `asset_history`) for exact numbers. Otherwise it falls back to a scripted guide. |
| **Start small (engaging, actionable)** | *Home*: weekly-amount calculator on real history, with honest worst/typical/best outcomes and the cost of waiting. Portfolio signals repeat it for your own mix. |
| **Accessible, engaging** | 20px base text + 3-step size control, Atkinson Hyperlegible font, read-aloud, keyboard/screen-reader support, dark mode, lessons with quizzes, scam practice. |

**Trust guardrails (the Blackstone angle):** the AI never recommends buying or selling,
never predicts prices, cites its periods, and never asks for passwords. Private-market
products are shown honestly: the app explains withdrawal limits using the real 2022–24
BREIT story (*Money out* tab), because informed investors don't panic-redeem.

## Data (all public)
- **Annual total returns 1928–2025** for large U.S. stocks, small stocks, 10-yr Treasuries,
  Baa corporate bonds, 3-month T-bills, U.S. home prices and gold: NYU Stern, Prof. Aswath
  Damodaran (updated Jan 5, 2026) → `data/market.json`. Verified against the source's own
  cumulative values.
- **Current conditions:** Federal Reserve (rate raised to 3.75–4.00%, Sept 16, 2026); BLS CPI
  (3.4%, Aug 2026). Edit `SNAPSHOT` in `app.py` when new figures come out.
- **Who invests / fraud:** Gallup, FTC Consumer Sentinel. Full source list on the Home page.

## Where to edit
- `labels_data.py`: the four sample documents and their pre-built labels. `check()` runs at startup and fails if any receipt isn't word-for-word in its document.
- `static/labels.js`: receipt verification, dollar math, label rendering, comparison, and AI extraction.
- `app.py`: `ASSETS` (plain-language descriptions, access rules), `SNAPSHOT`, and `CONTENT` (all copy, lessons, presets, chat fallbacks, sources).
- `static/insights.js`: portfolio math, signals, charts, research, and the AI layer.
- `static/app.js`: tabs, lessons, scam tools, login, and the chat shell.
- `templates/index.html`, `static/style.css`: structure and design.

## Notes
- The built-in BREIT/BXPE samples are short excerpts written from the funds' public terms (verified against SEC filings and fund sites), not verbatim filing text. Paste real filing text for live demos.
- Login and portfolio are a demo: stored only in the browser; the password is never stored.
- History assumes yearly rebalancing, and excludes fees and taxes. Private funds have no public
  yearly price series, so they're excluded from history (the app says so) but counted in access.
- Educational tool, not investment advice.
