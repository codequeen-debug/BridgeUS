/* Blackstone Bridge: the Investment Label.
   Paste the fine print -> one-page label with receipts.
   - Every claim carries a "receipt": an exact quote from the document.
   - Receipts are checked word-for-word against the document in the browser;
     anything the AI can't back up is flagged, not hidden.
   - All dollar math is done here in code, never by the AI. */
(function () {
  "use strict";
  var B = window.BRIDGE, APP = window.BridgeApp;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var SAMPLES = {}; B.labels.forEach(function (s) { SAMPLES[s.key] = s; });

  function money(n) { return (n < 0 ? "\u2212$" : "$") + Math.round(Math.abs(n)).toLocaleString("en-US"); }
  function pctTxt(p) { var t = (+p).toFixed(2).replace(/(\.\d*?)0+$/, "$1").replace(/\.$/, ""); return t + "%"; }
  function esc(t) { return String(t == null ? "" : t).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function parseMoney(v) { var n = parseFloat(String(v).replace(/[^0-9.]/g, "")); return isFinite(n) ? n : 0; }

  // ---------- Receipts: normalize with an index map, then find quotes ----------
  function normChar(c) {
    if (c === "\u2019" || c === "\u2018" || c === "`") return "'";
    if (c === "\u201c" || c === "\u201d") return '"';
    if (c === "\u2013" || c === "\u2014") return "-";
    return c.toLowerCase();
  }
  function normMap(text) {
    var out = "", map = [], space = false;
    for (var i = 0; i < text.length; i++) {
      var c = text[i];
      if (/\s/.test(c)) { if (!space && out.length) { out += " "; map.push(i); } space = true; continue; }
      space = false; out += normChar(c); map.push(i);
    }
    return { n: out, map: map };
  }
  function normStr(q) { return normMap(String(q || "")).n.trim().replace(/^["'\u2026.\s]+|["'\u2026\s]+$/g, ""); }
  function findQuote(doc, q) {
    var nq = normStr(q); if (nq.length < 6) return null;
    var i = doc.n.indexOf(nq);
    if (i < 0 && /[.!?]$/.test(nq)) { nq = nq.slice(0, -1); i = doc.n.indexOf(nq); }
    if (i < 0) return null;
    return [doc.map[i], doc.map[i + nq.length - 1] + 1];
  }

  // Walk a label in display order, verify every receipt and number it.
  function verify(label, docText) {
    var doc = normMap(docText), refs = [], n = 0, ok = 0, total = 0;
    function chk(item) {
      if (!item || !item.q) return;
      total++;
      var r = findQuote(doc, item.q);
      if (r) { ok++; n++; item._ref = n; refs.push({ n: n, range: r }); } else { item._ref = null; item._bad = true; }
    }
    var f = label.fees;
    label.flags.forEach(chk);
    chk(f.upfront); f.yearly.forEach(chk); chk(f.performance); chk(f.exit);
    label.access.items.forEach(chk);
    ["owns", "pricing", "risks"].forEach(function (k) { label[k].forEach(chk); });
    return { refs: refs, ok: ok, total: total };
  }

  // ---------- Dollar math ----------
  function costs(label, A, g) {
    var f = label.fees, gr = g / 100;
    var yearlyPct = f.yearly.reduce(function (s, x) { return s + (+x.pct || 0); }, 0);
    var up = f.upfront && f.upfront.pct != null ? A * f.upfront.pct / 100 : null;
    var yearly = A * (1 - (up || 0) / A) * yearlyPct / 100;
    var perf = 0;
    if (f.performance && f.performance.pct) {
      var gain = A * (1 - (up || 0) / A) * gr;
      perf = gr * 100 > (f.performance.hurdle || 0) ? gain * f.performance.pct / 100 : 0;
    }
    var exitAmt = f.exit ? (f.exit.pct != null ? A * f.exit.pct / 100 : null) : 0;
    function sim(yp, pf, hurdle, upPct, years) {
      var v = A * (1 - upPct / 100), clean = A;
      for (var y = 0; y < years; y++) {
        var gross = v * gr, p = pf && gr * 100 > hurdle ? gross * pf / 100 : 0;
        v = v + gross - p - v * yp / 100; clean *= 1 + gr;
      }
      return clean - v;
    }
    var known = f.yearly.length > 0;
    return {
      yearlyPct: yearlyPct, known: known, up: up, yearly: yearly, perf: perf, exitAmt: exitAmt,
      first: (up || 0) + yearly + perf,
      ten: known ? sim(yearlyPct, f.performance ? f.performance.pct : 0, f.performance ? f.performance.hurdle || 0 : 0, f.upfront && f.upfront.pct ? f.upfront.pct : 0, 10) : null,
      tenIndex: sim(0.03, 0, 0, 0, 10)
    };
  }

  // Six questions every investment document should answer.
  function clarity(label) {
    var okItems = function (arr) { return arr.some(function (i) { return i._ref; }); };
    var f = label.fees;
    var checks = [
      ["What you'd own", okItems(label.owns)],
      ["Yearly costs", f.yearly.some(function (i) { return i._ref; })],
      ["Other charges (upfront, selling early)", !!(f.upfront && f.upfront._ref && (!f.exit || f.exit.pct != null))],
      ["How to get your money out", okItems(label.access.items)],
      ["How the price is set", okItems(label.pricing)],
      ["What could go wrong", okItems(label.risks)],
    ];
    return { checks: checks, score: checks.filter(function (c) { return c[1]; }).length };
  }

  var LEVELS = [
    { name: "Any business day", tone: "ok" },
    { name: "Monthly, with limits", tone: "mid" },
    { name: "Quarterly, with limits", tone: "mid" },
    { name: "Locked or unclear", tone: "bad" }];

  // ---------- Rendering ----------
  function rc(item) {
    if (!item) return "";
    if (item._ref) return '<button type="button" class="rcpt" data-ref="' + item._ref + '" aria-label="Show source sentence ' + item._ref + '">' + item._ref + "</button>";
    if (item._bad) return '<span class="rcpt rcpt-bad" title="This quote was not found in the document">!</span>';
    return "";
  }
  function itemList(arr, cls) {
    if (!arr.length) return '<p class="nl-none">The document doesn\u2019t say.</p>';
    return '<ul class="nl-list ' + (cls || "") + '">' + arr.map(function (i) {
      return "<li" + (i._bad ? ' class="unverified"' : "") + ">" + esc(i.t) + " " + rc(i) + (i._bad ? '<span class="unv-note">Not found word-for-word in the document. Double-check this.</span>' : "") + "</li>";
    }).join("") + "</ul>";
  }

  var state = { key: null, label: null, doc: "", check: null, gain: 8 };
  function amount() { return Math.max(0, parseMoney($("#lb-amount").value)) || 1000; }

  function renderLabel() {
    var L = state.label, A = amount(), c = costs(L, A, state.gain), cl = clarity(L), f = L.fees;
    var lv = LEVELS[Math.max(0, Math.min(3, +L.access.level || 0))];
    var feeRows = "";
    function row(name, item, val, sub) { feeRows += '<div class="nl-row"><span class="nl-rn">' + name + " " + rc(item) + '</span><span class="nl-rv">' + val + (sub ? "<small>" + sub + "</small>" : "") + "</span></div>"; }
    if (f.upfront) row("Upfront charge", f.upfront, f.upfront.pct ? money(c.up) : "$0", f.upfront.pct ? pctTxt(f.upfront.pct) + (f.upfront.note ? " (" + esc(f.upfront.note.toLowerCase()) + ")" : "") : "none");
    else row("Upfront charge", null, '<span class="nl-q">Not stated</span>', "ask");
    if (f.yearly.length) f.yearly.forEach(function (y) { row(esc(y.name || "Yearly fee"), y, money(A * (1 - (c.up || 0) / A) * y.pct / 100), pctTxt(y.pct) + " a year"); });
    else row("Yearly fees", null, '<span class="nl-q">Not stated</span>', "ask");
    if (f.performance) row("Performance fee", f.performance, money(c.perf), pctTxt(f.performance.pct) + " of gains" + (f.performance.hurdle ? " when return is above " + pctTxt(f.performance.hurdle) : "") + ", at " + state.gain + "% growth");
    if (f.exit) row("Selling early", f.exit, f.exit.pct == null ? '<span class="nl-q">Yes, amount not stated</span>' : f.exit.pct ? money(c.exitAmt) : "$0", f.exit.pct ? "if you sell " + esc(f.exit.period) : f.exit.pct == null ? "if you sell " + esc(f.exit.period) + ". Ask how much." : "no fee");

    var h = '<header class="nl-head"><p class="nl-top">Investment label</p><h2 id="nl-name">' + esc(L.name) + '</h2><p class="nl-kind">' + esc(L.kind) + '</p><p class="nl-sum">' + esc(L.summary) + "</p></header>";
    if (L.flags.length) {
      h += '<section class="nl-sec nl-flags"><h3>\u26a0 ' + L.flags.length + " red flag" + (L.flags.length > 1 ? "s" : "") + "</h3>" + itemList(L.flags) +
        '<p class="nl-flag-cta">Don\u2019t send money. <a href="https://brokercheck.finra.org" target="_blank" rel="noopener">Look up the seller on FINRA BrokerCheck</a> or <a href="https://reportfraud.ftc.gov" target="_blank" rel="noopener">report it to the FTC</a>.</p></section>';
    }
    h += '<section class="nl-sec nl-cost"><h3>Cost on your ' + money(A) + "</h3>";
    h += c.known ? '<p class="nl-big">' + money(c.first) + '<span> in the first year</span></p>' : '<p class="nl-big nl-big-q">Fees not stated<span>, so the real cost is unknown</span></p>';
    if (c.known) h += '<label class="nl-gain">If its investments grow <strong>' + state.gain + '%</strong> a year, before fees<input type="range" id="nl-gain" min="0" max="15" step="1" value="' + state.gain + '"></label>';
    h += '<div class="nl-rows">' + feeRows + "</div>";
    if (c.ten != null) h += '<p class="nl-ten">Over 10 years at ' + state.gain + "% a year before fees, fees would take about <strong>" + money(c.ten) + "</strong> of your money. For comparison, a 0.03% index fund: <strong>" + money(c.tenIndex) + "</strong>.</p>";
    h += "</section>";
    h += '<section class="nl-sec"><h3>Getting your money out</h3><div class="nl-meter lv-' + lv.tone + '" aria-label="Access level: ' + lv.name + '">' +
      [0, 1, 2, 3].map(function (i) { return '<span class="' + (i <= L.access.level ? "on" : "") + '"></span>'; }).join("") + '<b>' + esc(lv.name) + "</b></div><p>" + esc(L.access.text) + "</p>" + itemList(L.access.items) + "</section>";
    h += '<section class="nl-sec"><h3>What you\u2019d own</h3>' + itemList(L.owns) + "</section>";
    h += '<section class="nl-sec"><h3>How the price is set</h3>' + itemList(L.pricing) + "</section>";
    h += '<section class="nl-sec"><h3>What could go wrong</h3>' + itemList(L.risks) + "</section>";
    h += '<section class="nl-sec nl-clarity"><h3>Does the document answer the basics? <span class="nl-score">' + cl.score + " of 6</span></h3><ul class=\"nl-checks\">" +
      cl.checks.map(function (x) { return '<li class="' + (x[1] ? "yes" : "no") + '"><span aria-hidden="true">' + (x[1] ? "\u2713" : "\u2715") + "</span>" + esc(x[0]) + '<span class="sr-only">: ' + (x[1] ? "answered" : "not answered") + "</span></li>"; }).join("") + "</ul>" +
      (L.missing.length ? '<p class="nl-miss-h">Not in this document:</p><ul class="nl-list nl-miss">' + L.missing.map(function (m) { return "<li>" + esc(m) + "</li>"; }).join("") + "</ul>" : "") + "</section>";
    if (L.questions.length) h += '<section class="nl-sec"><h3>Questions to ask before you invest</h3><ol class="nl-qs">' + L.questions.map(function (q) { return "<li>" + esc(q) + "</li>"; }).join("") + "</ol></section>";
    h += '<footer class="nl-foot"><p>' + state.check.ok + " of " + state.check.total + " receipts found word-for-word in the document." + (state.check.ok < state.check.total ? " Items marked ! could not be matched." : "") +
      " Dollar amounts are calculated by the app from the stated percentages (performance fee simplified; upfront charge shown at its maximum). Education only, not advice.</p><div class=\"nl-actions\">" +
      '<button type="button" class="btn btn-primary" id="nl-ask">Ask about this label</button>' +
      '<button type="button" class="btn btn-quiet" id="nl-save">' + (isCompared() ? "\u2713 In comparison" : "Add to comparison") + "</button>" +
      (L.flags.length ? '<a class="btn btn-quiet" href="#scams">Practice spotting scams</a>' : "") + "</div></footer>";
    $("#nlabel").innerHTML = h;

    if ($("#nl-gain")) $("#nl-gain").addEventListener("input", function (e) { state.gain = +e.target.value; renderLabel(); renderCompare(); var g = $("#nl-gain"); if (g) g.focus(); });
    $("#nl-ask").addEventListener("click", function () { APP.openChat("Explain this label for " + L.name + ": what should I watch out for?"); });
    $("#nl-save").addEventListener("click", function () { addCompare(); });
  }

  function renderSource() {
    var text = state.doc, refs = state.check.refs.slice().sort(function (a, b) { return a.range[0] - b.range[0]; });
    // Merge overlapping ranges so each highlight lists every receipt it backs.
    var segs = [];
    refs.forEach(function (r) {
      var last = segs[segs.length - 1];
      if (last && r.range[0] < last.end) { last.end = Math.max(last.end, r.range[1]); last.refs.push(r.n); }
      else segs.push({ start: r.range[0], end: r.range[1], refs: [r.n] });
    });
    var h = "", pos = 0;
    segs.forEach(function (sg) {
      h += esc(text.slice(pos, sg.start));
      h += '<mark data-refs="' + sg.refs.join(" ") + '"><sup>' + sg.refs.join(",") + "</sup>" + esc(text.slice(sg.start, sg.end)) + "</mark>";
      pos = sg.end;
    });
    h += esc(text.slice(pos));
    $("#src-text").innerHTML = h;
  }
  function showReceipt(n) {
    var m = $$("#src-text mark").filter(function (x) { return (" " + x.dataset.refs + " ").indexOf(" " + n + " ") >= 0; })[0];
    if (!m) return;
    $$("#src-text mark.flash").forEach(function (x) { x.classList.remove("flash"); });
    var box = $("#src-text");
    box.scrollTop = m.offsetTop - box.offsetTop - 40;
    var r = m.getBoundingClientRect();
    if (r.top < 0 || r.bottom > window.innerHeight) m.scrollIntoView({ block: "center", behavior: "smooth" });
    m.classList.add("flash");
    $("#lb-status").textContent = "Showing the sentence behind receipt " + n + ".";
  }

  function show(label, doc, key, note) {
    state.label = normalize(label); state.doc = doc; state.key = key;
    state.check = verify(state.label, doc);
    $("#lb-result").hidden = false;
    $("#lb-src-note").textContent = note || "";
    renderLabel(); renderSource();
    $$(".lb-samples .pick-btn").forEach(function (b) { b.setAttribute("aria-pressed", b.dataset.sample === key ? "true" : "false"); });
  }

  // Make any label (sample or AI) safe to render.
  function normalize(L) {
    L = JSON.parse(JSON.stringify(L || {}));
    var arr = function (v) { return Array.isArray(v) ? v.filter(function (i) { return i && (i.t || typeof i === "string"); }).map(function (i) { return typeof i === "string" ? { t: i } : { t: String(i.t || ""), q: i.q ? String(i.q) : "" }; }) : []; };
    var fee = function (o, needPct) { if (!o || typeof o !== "object") return null; var p = o.pct == null || o.pct === "" ? null : parseFloat(o.pct); if (needPct && !isFinite(p)) return null; return { pct: isFinite(p) ? p : null, hurdle: parseFloat(o.hurdle) || 0, note: o.note ? String(o.note) : "", period: o.period ? String(o.period) : "", name: o.name ? String(o.name) : "", q: o.q ? String(o.q) : "" }; };
    var F = L.fees || {};
    return {
      name: String(L.name || "Untitled document"), kind: String(L.kind || ""), summary: String(L.summary || ""),
      owns: arr(L.owns), pricing: arr(L.pricing), risks: arr(L.risks), flags: arr(L.flags),
      fees: {
        yearly: (Array.isArray(F.yearly) ? F.yearly : []).map(function (y) { return fee(y, true); }).filter(Boolean),
        performance: fee(F.performance, true), upfront: fee(F.upfront, false), exit: fee(F.exit, false) },
      access: { level: Math.max(0, Math.min(3, parseInt(L.access && L.access.level, 10) || 0)), text: String((L.access && L.access.text) || ""), items: arr(L.access && L.access.items) },
      questions: (Array.isArray(L.questions) ? L.questions : []).map(String).slice(0, 5),
      missing: (Array.isArray(L.missing) ? L.missing : []).map(String).slice(0, 6),
    };
  }

  function loadSample(key) {
    var s = SAMPLES[key]; if (!s) return;
    $("#lb-doc").value = s.doc;
    show(s.label, s.doc, key, (s.key === "pitch" ? "A made-up post for this demo, based on common scam patterns." : "Sample excerpt written from public terms for this demo.") +
      (s.filing ? " Source documents: " : ""));
    if (s.filing) { var a = document.createElement("a"); a.href = s.filing; a.target = "_blank"; a.rel = "noopener"; a.textContent = key === "index" ? "Investor.gov guide to funds" : "SEC filings"; $("#lb-src-note").appendChild(a); }
    $("#lb-status").textContent = "";
  }

  // ---------- Compare ----------
  var picked = ["breit", "index"];
  var customs = (APP.store.get("customLabels", []) || []).slice(0, 5);
  function allOptions() {
    var o = B.labels.map(function (s) { return { id: s.key, name: s.label.name, short: s.chip, label: s.label, doc: s.doc }; });
    customs.forEach(function (c, i) { o.push({ id: "c" + i, name: c.label.name, short: c.label.name.slice(0, 32), label: c.label, doc: c.doc }); });
    return o;
  }
  function currentId() {
    if (state.key) return state.key;
    var i = customs.findIndex(function (c) { return c.doc === state.doc; });
    return i >= 0 ? "c" + i : null;
  }
  function isCompared() { var id = currentId(); return id && picked.indexOf(id) >= 0; }
  function addCompare() {
    var id = currentId();
    if (!id) { customs.unshift({ label: state.label, doc: state.doc }); customs = customs.slice(0, 5); APP.store.set("customLabels", customs.map(function (c) { return { label: stripRefs(c.label), doc: c.doc.slice(0, 20000) }; })); id = "c0"; picked = picked.map(function (p) { return p[0] === "c" ? "c" + (+p.slice(1) + 1) : p; }); }
    if (picked.indexOf(id) < 0) { picked.push(id); if (picked.length > 3) picked.shift(); }
    renderLabel(); renderCompare();
    $("#h-lbcmp").scrollIntoView({ behavior: "smooth", block: "start" });
  }
  function stripRefs(L) { return JSON.parse(JSON.stringify(L, function (k, v) { return k === "_ref" || k === "_bad" ? undefined : v; })); }
  function renderCompare() {
    var opts = allOptions(), A = amount(), g = state.gain;
    $("#lbc-pick").innerHTML = opts.map(function (o) { return '<button type="button" class="pick-btn" data-id="' + o.id + '" aria-pressed="' + (picked.indexOf(o.id) >= 0) + '">' + esc(o.short) + "</button>"; }).join("");
    var cols = picked.map(function (id) { return opts.filter(function (o) { return o.id === id; })[0]; }).filter(Boolean).map(function (o) {
      var L = normalize(o.label), chk = verify(L, o.doc); return { o: o, L: L, c: costs(L, A, g), cl: clarity(L), chk: chk };
    });
    if (!cols.length) { $("#lbc-table").innerHTML = ""; return; }
    function r(name, fn) { return '<tr><th scope="row">' + name + "</th>" + cols.map(function (x) { return "<td>" + fn(x) + "</td>"; }).join("") + "</tr>"; }
    var q = '<span class="nl-q">Not stated</span>';
    var h = '<thead><tr><th scope="col"><span class="sr-only">Measure</span></th>' + cols.map(function (x) { return '<th scope="col">' + esc(x.L.name) + '<small>' + esc(x.L.kind) + "</small></th>"; }).join("") + "</tr></thead><tbody>";
    h += r("First-year cost on " + money(A), function (x) { return x.c.known ? "<strong>" + money(x.c.first) + "</strong>" : q; });
    h += r("Yearly fees", function (x) { return x.c.known ? pctTxt(x.c.yearlyPct) + " (" + money(x.c.yearly) + ")" : q; });
    h += r("Performance fee", function (x) { var p = x.L.fees.performance; return p ? pctTxt(p.pct) + " of gains above " + pctTxt(p.hurdle) : x.c.known ? "None" : q; });
    h += r("Upfront charge", function (x) { var u = x.L.fees.upfront; return u ? (u.pct ? "Up to " + pctTxt(u.pct) + " (" + money(x.c.up) + ")" : "None") : q; });
    h += r("Selling early", function (x) { var e = x.L.fees.exit; return e ? (e.pct == null ? "Yes, amount not stated" : e.pct ? money(x.c.exitAmt) + " " + esc(e.period) : "No fee") : q; });
    h += r("Getting money out", function (x) { var lv = LEVELS[x.L.access.level]; return '<span class="lvl lvl-' + lv.tone + '">' + esc(lv.name) + "</span>"; });
    h += r("Fees over 10 years at " + g + "%", function (x) { return x.c.ten != null ? "<strong>" + money(x.c.ten) + "</strong>" : q; });
    h += r("Answers the basics", function (x) { return x.cl.score + " of 6"; });
    h += r("Red flags", function (x) { return x.L.flags.length ? '<span class="neg">' + x.L.flags.length + "</span>" : "None found"; });
    $("#lbc-table").innerHTML = h + "</tbody>";
  }

  // ---------- AI extraction ----------
  var sample = null, canImages = false;
  var SCHEMA = '{"name":"","kind":"","summary":"","owns":[{"t":"","q":""}],' +
    '"fees":{"yearly":[{"name":"","pct":0,"q":""}],"performance":{"pct":0,"hurdle":0,"q":""},"upfront":{"pct":0,"note":"","q":""},"exit":{"pct":0,"period":"","q":""}},' +
    '"access":{"level":0,"text":"","items":[{"t":"","q":""}]},"pricing":[{"t":"","q":""}],"risks":[{"t":"","q":""}],"flags":[{"t":"","q":""}],"questions":[""],"missing":[""]}';
  function prompt(doc, fromImage) {
    return [
      "You turn investment documents into a plain-English 'investment label' for first-time investors (Gen Z and young millennials).",
      "Reply with ONLY one JSON object in exactly this shape" + (fromImage ? ', plus a "source_text" field' : "") + ":",
      SCHEMA,
      "RULES:",
      "- Use ONLY what the document says. No outside knowledge about the product, even if you recognize it.",
      "- Every \"q\" must be copied EXACTLY, character for character, from the document" + (fromImage ? " (from your source_text transcription)" : "") + ": one full sentence or clause, 6 to 40 words. Never paraphrase inside q. If you can't quote it, leave the item out.",
      "- Every \"t\" is your own plain-English rewrite, under 20 words, no jargon.",
      "- Percentages are numbers: 1.25 means 1.25%. fees.yearly lists every ongoing yearly fee (management, servicing, expense ratio).",
      "- performance: set to null if none is described. upfront: null if the document doesn't mention it; pct 0 if it says there is none. exit: null if not mentioned; pct null if a penalty exists but its size isn't stated; pct 0 if it says there is none.",
      "- access.level: 0 = sell any business day; 1 = monthly with limits; 2 = quarterly with limits; 3 = locked, conditional, or unclear.",
      "- flags: scam or pressure signs only (guaranteed or unrealistic returns, urgency, crypto/gift-card/wire payment, pay-to-withdraw, secrecy, unregistered seller, recruiting). Empty array if none.",
      "- missing: important basics the document does NOT say (e.g. fees, how to withdraw, risks).",
      "- questions: 2 or 3 short questions to ask before investing.",
      "- name: the product's name as written; kind: a plain description (e.g. 'Private real estate fund (non-traded)'). If this is not about an investment, say so in summary and leave the lists empty.",
      fromImage ? "- The document is in the attached image(s). First transcribe all of its text exactly into source_text." : "",
      fromImage ? "" : "\nDOCUMENT:\n\"\"\"\n" + doc + "\n\"\"\"",
    ].join("\n");
  }
  var ctl = null;
  function runAI(doc, images) {
    if (!sample) { $("#lb-status").textContent = "Custom documents need the AI, which works when you open the published app on claude.ai. Try one of the samples above."; return; }
    if (!images && doc.trim().length < 80) { $("#lb-status").textContent = "Paste a bit more text: at least a few sentences about fees, withdrawals or risks."; return; }
    ctl = new AbortController();
    var btn = $("#lb-make"), started = Date.now();
    btn.disabled = true;
    var st = $("#lb-status");
    st.innerHTML = '<span class="thinking">Reading the document and checking every quote\u2026 <span id="lb-secs">0</span>s</span> <button type="button" class="stop-btn" id="lb-stop">Stop</button>';
    $("#lb-stop").onclick = function () { ctl.abort(); };
    var timer = setInterval(function () { var s = $("#lb-secs"); if (s) s.textContent = Math.round((Date.now() - started) / 1000); }, 1000);
    var opts = { signal: ctl.signal };
    if (images) opts.images = images;
    sample.json(prompt(doc.slice(0, 45000), !!images), opts).then(function (res) {
      if (!res || typeof res !== "object") throw { code: "invalid_json" };
      var text = images ? String(res.source_text || "") : doc;
      if (images) $("#lb-doc").value = text;
      show(res, text, null, images ? "Text transcribed from your screenshot by AI. Receipts are checked against this transcription." : "Your document. Highlights show every sentence the label relies on.");
      st.textContent = "Done. " + state.check.ok + " of " + state.check.total + " receipts found word-for-word in your document.";
      $("#nlabel").scrollIntoView({ behavior: "smooth", block: "start" });
    }).catch(function (e) {
      var code = e && e.code;
      if (["not_granted", "sampling_disabled", "not_declared", "capability_disabled", "capability_removed"].indexOf(code) >= 0) { sample = null; st.textContent = "AI isn't available here, so only the samples work. Try one above."; return; }
      st.textContent = code === "cancelled" ? "Stopped." : code === "invalid_json" ? "The AI's answer couldn't be read. Please try again, or paste a shorter section." :
        code === "prompt_too_large" ? "That document is too long. Paste just the fees, withdrawals and risks sections." :
        code === "rate_limited" ? "Too many requests right now. Wait a minute and try again." : "Something went wrong. Please try again.";
    }).then(function () { clearInterval(timer); btn.disabled = false; });
  }

  // ---------- Mini label on Home ----------
  function renderMini() {
    var s = SAMPLES.breit; if (!s || !$("#ml-rows")) return;
    var L = normalize(s.label); verify(L, s.doc);
    var c = costs(L, 1000, 8), cl = clarity(L);
    $(".mini-label .ml-name").textContent = L.name;
    $(".mini-label .ml-kind").textContent = L.kind;
    var rows = [
      ["First-year cost on $1,000", money(c.first), "at 8% growth, incl. max upfront charge"],
      ["Getting money out", LEVELS[L.access.level].name, "2% of the fund a month, 5% a quarter"],
      ["Selling within a year", money(c.exitAmt), "2% early repurchase deduction"],
      ["Fees over 10 years", money(c.ten), "vs " + money(c.tenIndex) + " in an index fund"],
      ["Answers the basics", cl.score + " of 6", "every line has a receipt"]];
    $("#ml-rows").innerHTML = rows.map(function (r) { return "<div><dt>" + r[0] + "</dt><dd>" + r[1] + "<small>" + r[2] + "</small></dd></div>"; }).join("");
  }

  // ---------- Wiring ----------
  function init() {
    renderMini();
    $$(".lb-samples .pick-btn").forEach(function (b) { b.addEventListener("click", function () { location.hash = "#label/" + b.dataset.sample; }); });
    $("#lb-make").addEventListener("click", function () {
      var doc = $("#lb-doc").value;
      var match = B.labels.filter(function (s) { return s.doc.trim() === doc.trim(); })[0];
      if (match) { loadSample(match.key); return; }
      runAI(doc, null);
    });
    $("#lb-amount").addEventListener("change", function () { $("#lb-amount").value = Math.round(amount()).toLocaleString("en-US"); if (state.label) renderLabel(); renderCompare(); });
    $("#lb-amount").addEventListener("keydown", function (e) { if (e.key === "Enter") $("#lb-amount").dispatchEvent(new Event("change")); });
    $("#lb-image").addEventListener("change", function (e) { var f = e.target.files && e.target.files[0]; if (f) runAI("", [f]); e.target.value = ""; });
    $("#nlabel").addEventListener("click", function (e) { var b = e.target.closest(".rcpt[data-ref]"); if (b) showReceipt(+b.dataset.ref); });
    $("#lbc-pick").addEventListener("click", function (e) {
      var b = e.target.closest(".pick-btn"); if (!b) return;
      var id = b.dataset.id, i = picked.indexOf(id);
      if (i >= 0) { if (picked.length > 1) picked.splice(i, 1); } else { picked.push(id); if (picked.length > 3) picked.shift(); }
      renderCompare(); if (state.label) renderLabel();
    });
    renderCompare();
    if (window.claude && typeof window.claude.use === "function") {
      window.claude.use("sample").then(function (fn) {
        if (!fn) return; sample = fn;
        if (fn.limits) fn.limits().then(function (l) { canImages = !!(l && l.images); $("#lb-upload-wrap").hidden = !canImages; }).catch(function () {});
      }).catch(function () {});
    }
  }
  init();

  window.BridgeLabels = {
    onRoute: function (page, sub) {
      if (page !== "label") return;
      if (sub && SAMPLES[sub]) { if (state.key !== sub) loadSample(sub); }
      else if (!state.label) loadSample("breit");
    },
    summaryText: function () {
      if (!state.label) return "";
      var L = state.label, c = costs(L, amount(), state.gain);
      return "Name: " + L.name + " (" + L.kind + "). " + L.summary + " Amount: " + money(amount()) + ". First-year cost at " + state.gain + "% growth: " + (c.known ? money(c.first) : "fees not stated") +
        ". Yearly fees: " + L.fees.yearly.map(function (y) { return y.name + " " + y.pct + "%"; }).join(", ") +
        (L.fees.performance ? ". Performance fee " + L.fees.performance.pct + "% above " + L.fees.performance.hurdle + "% hurdle" : "") +
        (L.fees.exit ? ". Early sale: " + (L.fees.exit.pct == null ? "penalty, size not stated" : L.fees.exit.pct + "% " + L.fees.exit.period) : "") +
        ". Access: " + L.access.text + " Red flags: " + (L.flags.map(function (f) { return f.t; }).join("; ") || "none") + ". Missing from document: " + (L.missing.join("; ") || "nothing major") + ".";
    }
  };
  var cur = (location.hash || "").slice(1).split("/");
  window.BridgeLabels.onRoute(cur[0], cur[1]);
})();
