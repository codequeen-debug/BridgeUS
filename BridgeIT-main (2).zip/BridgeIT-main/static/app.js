/* Blackstone Bridge — page behaviour. Content comes from window.BRIDGE
   (rendered by Flask from CONTENT in app.py). */
(function () {
  "use strict";
  var B = window.BRIDGE || {};
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var money = function (n) { return "$" + Math.round(n).toLocaleString("en-US"); };

  // ---------- Safe storage (per-viewer conveniences only) ----------
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem("bridge:" + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem("bridge:" + k, JSON.stringify(v)); } catch (e) {} },
    del: function (k) { try { localStorage.removeItem("bridge:" + k); } catch (e) {} }
  };

  // ---------- Text size ----------
  function setSize(n) {
    document.documentElement.setAttribute("data-size", String(n));
    $$(".size-control button").forEach(function (b) { b.setAttribute("aria-pressed", b.dataset.size === String(n) ? "true" : "false"); });
    store.set("size", n);
  }
  $$(".size-control button").forEach(function (b) { b.addEventListener("click", function () { setSize(+b.dataset.size); }); });
  setSize(store.get("size", 1));

  // ---------- Router ----------
  var pages = ["start", "label", "profile", "research", "learn", "scams", "access"];
  var firstRoute = true;
  function route() {
    var hash = (location.hash || "#start").slice(1);
    var parts = hash.split("/");
    var page = pages.indexOf(parts[0]) >= 0 ? parts[0] : "start";
    var sub = parts[1] || "";
    stopSpeaking();

    $$(".page").forEach(function (p) { p.hidden = p.dataset.page !== page; });
    $$(".tabs a").forEach(function (a) {
      if (a.dataset.tab === (page === "scams" ? "learn" : page)) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current");
    });

    var focusEl = null;
    if (page === "learn") {
      var slug = B.lessons.indexOf(sub) >= 0 ? sub : (store.get("lastLesson", "") || B.lessons[0]);
      showLesson(slug);
      if (sub) focusEl = $("#lt-" + slug);
    } else if (page === "profile") {
      renderProfile();
    }
    if (window.BridgeInsights) window.BridgeInsights.onRoute(page);
    if (window.BridgeLabels) window.BridgeLabels.onRoute(page, sub);
    if (!focusEl) focusEl = $('.page[data-page="' + page + '"] h1:not([hidden])');
    var anchor = page === "scams" && sub ? document.getElementById(sub) : null;

    if (!firstRoute) {
      if (anchor) { anchor.scrollIntoView(); }
      else window.scrollTo(0, 0);
      if (focusEl && !anchor) focusEl.focus({ preventScroll: true });
    } else if (anchor) { anchor.scrollIntoView(); }
    firstRoute = false;
    document.title = (focusEl ? focusEl.textContent.trim() + " | " : "") + "Blackstone Bridge";
  }
  window.addEventListener("hashchange", route);

  // ---------- Read aloud ----------
  var speaking = false;
  function stopSpeaking() {
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    speaking = false;
    $$("[data-listen]").forEach(function (b) { b.textContent = "Read this page aloud"; });
  }
  $$("[data-listen]").forEach(function (btn) {
    if (!("speechSynthesis" in window)) { btn.hidden = true; return; }
    btn.addEventListener("click", function () {
      if (speaking) { stopSpeaking(); return; }
      var page = btn.closest(".page");
      var text = $$("h1, h2, p, .choice-q", page).filter(function (el) { return el.offsetParent !== null && !el.closest("[data-listen]"); })
        .map(function (el) { return el.textContent.trim(); }).join(". ");
      var u = new SpeechSynthesisUtterance(text);
      u.rate = 0.92;
      u.onend = stopSpeaking;
      window.speechSynthesis.speak(u);
      speaking = true;
      btn.textContent = "Stop reading";
    });
  });

  // ---------- Lessons ----------
  var done = store.get("done", []);
  function showLesson(slug) {
    $$(".lesson").forEach(function (l) { l.hidden = l.dataset.lesson !== slug; });
    $$("[data-lesson-link]").forEach(function (a) {
      if (a.dataset.lessonLink === slug) a.setAttribute("aria-current", "step"); else a.removeAttribute("aria-current");
    });
    store.set("lastLesson", slug);
    var active = $('[data-lesson-link="' + slug + '"]');
    if (active && active.scrollIntoView && window.innerWidth < 880) active.scrollIntoView({ block: "nearest", inline: "center" });
  }
  function paintProgress() {
    $$("[data-lesson-link]").forEach(function (a) {
      var isDone = done.indexOf(a.dataset.lessonLink) >= 0;
      a.classList.toggle("done", isDone);
      $(".ll-done", a).hidden = !isDone;
    });
    $("#learn-progress").textContent = done.length + " of " + B.lessons.length;
  }
  $$(".quiz").forEach(function (q) {
    var answer = +q.dataset.answer;
    var fb = $(".quiz-fb", q);
    $$(".quiz-opt", q).forEach(function (btn) {
      btn.addEventListener("click", function () {
        var pick = +btn.dataset.opt;
        $$(".quiz-opt", q).forEach(function (b) { b.classList.remove("is-right", "is-wrong"); });
        if (pick === answer) {
          btn.classList.add("is-right");
          fb.textContent = fb.dataset.right; fb.className = "quiz-fb ok";
          if (done.indexOf(q.dataset.quiz) < 0) { done.push(q.dataset.quiz); store.set("done", done); paintProgress(); }
        } else {
          btn.classList.add("is-wrong");
          fb.textContent = fb.dataset.wrong + " Try another answer."; fb.className = "quiz-fb no";
        }
      });
    });
  });
  paintProgress();

  // ---------- Fee calculator ----------
  $$("[data-calc]").forEach(function (c) {
    var amt = $("[data-calc-amount]", c), fee = $("[data-calc-fee]", c);
    function calc() {
      var P = +amt.value, f = +fee.value / 100, r = 0.06, y = 20;
      var a = P * Math.pow(1 + r, y), b = P * Math.pow((1 + r) * (1 - f), y);
      $("[data-calc-fee-out]", c).textContent = (+fee.value).toFixed(1) + "%";
      $("[data-calc-a]", c).textContent = money(a);
      $("[data-calc-b]", c).textContent = money(b);
      $("[data-calc-lost]", c).textContent = money(a - b);
      $("[data-calc-bar-a]", c).style.width = "100%";
      $("[data-calc-bar-b]", c).style.width = (b / a * 100).toFixed(1) + "%";
    }
    amt.addEventListener("change", calc); fee.addEventListener("input", calc); calc();
  });

  // ---------- Scam checklist ----------
  var flags = $$(".flag");
  function verdict() {
    var n = flags.filter(function (f) { return f.getAttribute("aria-pressed") === "true"; }).length;
    var v = $("#verdict"), t = $("#verdict-title"), b = $("#verdict-body");
    if (n === 0) {
      v.dataset.level = "0"; t.textContent = "No warning signs ticked yet.";
      b.textContent = "Even with no warning signs, check that the seller is licensed before you pay anything.";
    } else if (n <= 2) {
      v.dataset.level = "1"; t.textContent = n + " warning sign" + (n > 1 ? "s" : "") + ". Slow down.";
      b.textContent = "Don't pay or sign anything yet. Ask for the offer in writing, look the seller up on FINRA BrokerCheck, and talk it over with someone you trust.";
    } else {
      v.dataset.level = "2"; t.textContent = n + " warning signs. This looks like a scam.";
      b.textContent = "Stop contact and don't send money. If you have already paid, contact your bank today and report it. You are not foolish: these schemes are designed by professionals.";
    }
  }
  flags.forEach(function (f) {
    f.addEventListener("click", function () {
      f.setAttribute("aria-pressed", f.getAttribute("aria-pressed") === "true" ? "false" : "true");
      verdict();
    });
  });

  // ---------- Phishing practice ----------
  var found = {};
  $$(".hot").forEach(function (h) {
    h.addEventListener("click", function () {
      var i = h.dataset.hot;
      found[i] = true;
      h.classList.add("found");
      $('[data-note="' + i + '"]').hidden = false;
      var n = Object.keys(found).length;
      $("#phish-count").textContent = n === 3 ? "All 3 found. Well spotted." : n + " of 3 found";
    });
  });

  // ---------- Pyramid simulator ----------
  var USA = 340000000, WORLD = 8200000000;
  function pyr() {
    var r = +$("#pyr-r").value, L = +$("#pyr-l").value, total = 0, level = 1;
    for (var i = 0; i <= L; i++) { total += level; level *= r; }
    $("#pyr-r-out").textContent = r; $("#pyr-l-out").textContent = L;
    $("#pyr-total").textContent = total.toLocaleString("en-US");
    var bar = $(".pyr-bar"), note = $("#pyr-note");
    $("#pyr-fill").style.width = Math.min(100, total / USA * 100) + "%";
    bar.classList.toggle("over", total > USA);
    if (total > WORLD) note.textContent = "More people than exist on Earth. The scheme collapses long before this, and most people lose their money.";
    else if (total > USA) note.textContent = "More than everyone in the United States (about 340 million people). The last people in can never be paid.";
    else note.textContent = "That is " + (total / USA * 100).toFixed(total / USA < 0.01 ? 2 : 0) + "% of the U.S. population. Add a few more levels.";
  }
  ["#pyr-r", "#pyr-l"].forEach(function (s) { $(s).addEventListener("input", pyr); }); pyr();

  // ---------- Fraud chart toggle ----------
  function fraudChart(kind) {
    var rows = kind === "median" ? B.numbers.fraud_median : B.numbers.fraud_rate;
    var max = kind === "median" ? 1650 : 50;
    $("#fraud-sub").textContent = kind === "median"
      ? "Median amount lost per fraud report that involved a loss, 2024."
      : "Share of fraud reports in which the person lost money, 2024.";
    $("#fraud-bars").innerHTML = rows.map(function (r) {
      var val = kind === "median" ? money(r[1]) : r[1] + "%";
      return '<div class="hbar"><span class="hb-label">' + r[0] + '</span><span class="hb-track"><span class="hb-fill ' +
        (kind === "median" ? "fill-rust" : "fill-navy") + '" style="--v:' + (r[1] / max * 100).toFixed(1) + '%"></span></span><span class="hb-val">' + val + "</span></div>";
    }).join("");
    $$(".toggle [data-fraud]").forEach(function (b) { b.setAttribute("aria-pressed", b.dataset.fraud === kind ? "true" : "false"); });
  }
  $$(".toggle [data-fraud]").forEach(function (b) { b.addEventListener("click", function () { fraudChart(b.dataset.fraud); }); });
  fraudChart("rate");

  // ---------- Withdrawal limit example ----------
  function ws() {
    var x = +$("#ws").value, share = Math.min(1, 2 / x), paid = 10000 * share;
    $("#ws-out").textContent = x + "%";
    $("#ws-paid").style.width = share * 100 + "%";
    $("#ws-wait").style.width = (1 - share) * 100 + "%";
    $("#ws-paid-out").textContent = money(paid);
    $("#ws-wait-out").textContent = money(10000 - paid);
  }
  $("#ws").addEventListener("input", ws); ws();

  // ---------- Share ----------
  $("#share-btn").addEventListener("click", function () {
    var url = location.href.split("#")[0], note = $("#share-note");
    function ok() { note.textContent = "Link copied. Paste it into a message to share."; }
    function fail() { note.textContent = "Copy this link: " + url; }
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(url).then(ok, fail);
      else fail();
    } catch (e) { fail(); }
  });

  // ---------- Login / profile ----------
  function renderProfile() {
    var user = store.get("user", null);
    $("#login-view").hidden = !!user;
    $("#profile-view").hidden = !user;
    $("#head-login").textContent = user ? user.name : "Log in";
    if (!user) return;
    $("#pf-name").textContent = user.name;
    $("#pf-initial").textContent = user.name.charAt(0).toUpperCase();
    $("#pf-lessons").textContent = done.length;
    $("#pf-progress-fill").style.width = (done.length / B.lessons.length * 100) + "%";
    if (window.BridgeInsights) window.BridgeInsights.renderPortfolio();
    var next = B.lessons.filter(function (s) { return done.indexOf(s) < 0; })[0];
    var cont = $("#pf-continue");
    cont.href = next ? "#learn/" + next : "#scams";
    cont.textContent = next ? "Continue learning" : "All lessons done. Practice spotting scams";
  }
  $("#login-form").addEventListener("submit", function (e) {
    e.preventDefault();
    var name = $("#lg-name").value.trim(), email = $("#lg-email").value.trim(), pass = $("#lg-pass").value;
    var err = $("#login-error");
    if (!name) { err.textContent = "Enter your first name."; $("#lg-name").focus(); return; }
    if (!/^\S+@\S+\.\S+$/.test(email)) { err.textContent = "Enter an email address, like name@example.com."; $("#lg-email").focus(); return; }
    if (!pass) { err.textContent = "Enter your password."; $("#lg-pass").focus(); return; }
    err.textContent = "";
    store.set("user", { name: name });   // the password is never stored
    $("#lg-pass").value = "";
    renderProfile();
    $("#h-profile-in").focus();
  });
  $("#demo-login").addEventListener("click", function () {
    store.set("user", { name: "Jordan" });
    renderProfile();
    $("#h-profile-in").focus();
  });
  $("#logout").addEventListener("click", function () { store.del("user"); renderProfile(); $("#h-profile").focus(); });
  if (store.get("user", null)) $("#head-login").textContent = store.get("user").name;

  // ---------- Chat ----------
  var C = B.chat, log = $("#chat-log"), chat = $("#chat"), launch = $("#chat-launch"), started = false;
  function addMsg(who, text, actions) {
    var m = document.createElement("div");
    m.className = "msg msg-" + who;
    var p = document.createElement("p"); p.textContent = text; m.appendChild(p);
    if (actions && actions.length) {
      var row = document.createElement("div"); row.className = "msg-actions";
      actions.forEach(function (a) { row.appendChild(a); });
      m.appendChild(row);
    }
    log.appendChild(m);
    log.scrollTop = log.scrollHeight;
  }
  function linkBtn(label, href) {
    var a = document.createElement("a"); a.href = href; a.textContent = label;
    a.addEventListener("click", function () { if (window.innerWidth <= 520) closeChat(); });
    return a;
  }
  function handoffBtns() {
    var call = document.createElement("button"); call.type = "button"; call.className = "solid"; call.textContent = "Request a call back";
    call.addEventListener("click", function () {
      call.disabled = true;
      addMsg("bot", "Done. In the real app, a licensed adviser would call you within one business day. They will never ask for your password or PIN, and they will never rush you.");
    });
    return [call, linkBtn("Look up an adviser on BrokerCheck", "https://brokercheck.finra.org")];
  }
  function answer(q) {
    var t = q.toLowerCase(), best = null, bestLen = 0;
    C.topics.forEach(function (topic) {
      topic.keys.forEach(function (k) {
        var re = new RegExp("(^|[^a-z])" + k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
        if (re.test(t) && k.length > bestLen) { best = topic; bestLen = k.length; }
      });
    });
    if (!best) { addMsg("bot", C.fallback, handoffBtns().slice(0, 1)); return; }
    var acts = (best.go || []).map(function (g) { return linkBtn(g[0], g[1]); });
    if (best.handoff) acts = handoffBtns();
    addMsg("bot", best.reply, acts);
  }
  function say(text) {
    if (!text) return;
    addMsg("me", text);
    var ai = window.BridgeApp.aiAnswer;
    if (ai && !/^talk to a person$/i.test(text)) { ai(text, log); return; }
    setTimeout(function () { answer(text); }, 250);
  }
  function openChat(prefill) {
    chat.hidden = false; launch.setAttribute("aria-expanded", "true");
    if (!started) {
      started = true;
      addMsg("bot", C.hello);
      $("#chat-chips").innerHTML = "";
      C.chips.forEach(function (label) {
        var b = document.createElement("button"); b.type = "button"; b.textContent = label;
        b.addEventListener("click", function () { say(label); });
        $("#chat-chips").appendChild(b);
      });
    }
    if (prefill) say(prefill);
    $("#chat-input").focus();
  }
  function closeChat() { chat.hidden = true; launch.setAttribute("aria-expanded", "false"); launch.focus(); }
  launch.addEventListener("click", function () { openChat(); });
  $("#chat-close").addEventListener("click", closeChat);
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && !chat.hidden) closeChat(); });
  $$("[data-open-chat]").forEach(function (b) { b.addEventListener("click", function () { openChat(b.dataset.chatSay); }); });
  $("#chat-form").addEventListener("submit", function (e) {
    e.preventDefault();
    var inp = $("#chat-input"), v = inp.value.trim();
    if (v) { say(v); inp.value = ""; }
  });

  window.BridgeApp = { store: store, addMsg: addMsg, linkBtn: linkBtn, handoffBtns: handoffBtns,
    ruleAnswer: answer, openChat: openChat, done: function () { return done; }, aiAnswer: null };
  route();
})();
