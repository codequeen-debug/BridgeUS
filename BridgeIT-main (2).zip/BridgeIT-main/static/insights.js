/* Blackstone Bridge: portfolio insights, research, and plain-English AI.
   Data: window.BRIDGE.market (NYU Stern annual returns), .assets, .snapshot.
   Everything here works without AI; AI features light up when the viewer
   can use Claude (published claude.ai page), and fall back cleanly if not. */
(function () {
  "use strict";
  var B = window.BRIDGE, APP = window.BridgeApp;
  var M = B.market, START = M.start, END = M.end;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var A = {}; B.assets.forEach(function (a) { A[a.key] = a; });
  var CHARTABLE = B.assets.filter(function (a) { return a.series; }).map(function (a) { return a.key; });

  // ---------- Formatting ----------
  function money(n) { return (n < 0 ? "\u2212$" : "$") + Math.round(Math.abs(n)).toLocaleString("en-US"); }
  function pct(x, d, sign) {
    var v = (x * 100).toFixed(d == null ? 1 : d);
    if (v === "-0.0" || v === "-0") v = v.slice(1);
    var n = parseFloat(v);
    return (sign && n > 0 ? "+" : "") + (n < 0 ? "\u2212" + v.slice(1) : v) + "%";
  }
  function esc(t) { return String(t).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function parseMoney(v) { var n = parseFloat(String(v).replace(/[^0-9.]/g, "")); return isFinite(n) ? n : 0; }

  // ---------- Math ----------
  function r(key, y) { return M.series[A[key].series][y - START]; }
  // Yearly returns of a mix, rebalanced each year. Assets without history are left out and the rest re-weighted.
  function mixReturns(weights, y0, y1) {
    var keys = Object.keys(weights).filter(function (k) { return A[k] && A[k].series && weights[k] > 0; });
    var tot = keys.reduce(function (s, k) { return s + weights[k]; }, 0);
    var out = [];
    for (var y = y0; y <= y1; y++) {
      out.push(tot ? keys.reduce(function (s, k) { return s + weights[k] / tot * r(k, y); }, 0) : 0);
    }
    return out;
  }
  function stats(rets, y0) {
    var v = 1, peak = 1, maxDD = 0, ddYear = null, best = { r: -Infinity }, worst = { r: Infinity }, down = 0, growth = [1];
    rets.forEach(function (x, i) {
      v *= 1 + x; growth.push(v);
      if (v > peak) peak = v;
      var dd = v / peak - 1; if (dd < maxDD) { maxDD = dd; ddYear = y0 + i; }
      if (x > best.r) best = { r: x, y: y0 + i };
      if (x < worst.r) worst = { r: x, y: y0 + i };
      if (x < 0) down++;
    });
    return { cagr: Math.pow(v, 1 / rets.length) - 1, total: v, best: best, worst: worst, down: down, n: rets.length, growth: growth, maxDD: maxDD, ddYear: ddYear };
  }
  function assetStats(key, years) { var y0 = END - years + 1; return stats(mixReturns(one(key), y0, END), y0); }
  function one(k) { var o = {}; o[k] = 1; return o; }

  // ---------- Holdings ----------
  function demoHoldings() { return B.profile.demo.map(function (h) { return { key: h[0], amt: h[1] }; }); }
  function getHoldings() {
    var h = APP.store.get("holdings", null);
    return Array.isArray(h) && h.length ? h.filter(function (x) { return A[x.key]; }) : demoHoldings();
  }
  function setHoldings(h) { APP.store.set("holdings", h); }
  function summarize(h) {
    var total = h.reduce(function (s, x) { return s + x.amt; }, 0) || 0;
    var w = {}, groups = {}, liquid = 0, noHist = 0;
    h.forEach(function (x) {
      w[x.key] = (w[x.key] || 0) + x.amt;
      var g = A[x.key].group; groups[g] = (groups[g] || 0) + x.amt;
      if (A[x.key].days <= 7) liquid += x.amt;
      if (!A[x.key].series) noHist += x.amt;
    });
    var largest = null;
    Object.keys(w).forEach(function (k) { if (!largest || w[k] > w[largest]) largest = k; });
    return { total: total, weights: w, groups: groups, liquid: liquid, noHist: noHist, largest: largest };
  }
  function mixStats(sum, years) {
    var y0 = END - years + 1;
    return stats(mixReturns(sum.weights, y0, END), y0);
  }

  // ---------- SVG line chart ----------
  function niceStep(range, target) {
    var raw = range / target, mag = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / mag;
    return (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10) * mag;
  }
  function shortMoney(v) {
    if (v >= 1e6) return "$" + (v / 1e6).toFixed(v >= 1e7 ? 0 : 1) + "M";
    if (v >= 1e3) return "$" + (v / 1e3).toFixed(v >= 1e5 ? 0 : v >= 1e4 ? 0 : 1) + "k";
    return "$" + Math.round(v);
  }
  function lineChart(el, y0, lines, label) {
    var W = 820, H = 340, L = 70, R = 120, T = 16, Bm = 36;
    var n = lines[0].vals.length, max = 0, min = Infinity;
    lines.forEach(function (l) { l.vals.forEach(function (v) { if (v > max) max = v; if (v < min) min = v; }); });
    min = Math.min(min, lines[0].vals[0]) * 0.95; max *= 1.05;
    var step = niceStep(max - min, 5), lo = Math.floor(min / step) * step, hi = Math.ceil(max / step) * step;
    var x = function (i) { return L + (W - L - R) * i / (n - 1); };
    var y = function (v) { return T + (H - T - Bm) * (1 - (v - lo) / (hi - lo)); };
    var g = '<svg viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="' + esc(label) + '">';
    for (var t = lo; t <= hi + step / 2; t += step) {
      g += '<line class="grid" x1="' + L + '" x2="' + (W - R) + '" y1="' + y(t) + '" y2="' + y(t) + '"/>';
      g += '<text class="ax" x="' + (L - 10) + '" y="' + (y(t) + 5) + '" text-anchor="end">' + shortMoney(t) + "</text>";
    }
    var every = Math.max(1, Math.ceil((n - 1) / 6));
    for (var i = 0; i < n; i += every) g += '<text class="ax" x="' + x(i) + '" y="' + (H - 10) + '" text-anchor="middle">' + (i === 0 ? "Start" : (y0 - 1 + i)) + "</text>";
    if ((n - 1) % every) g += '<text class="ax" x="' + x(n - 1) + '" y="' + (H - 10) + '" text-anchor="middle">' + (y0 - 1 + n - 1) + "</text>";
    var ends = lines.map(function (l) { return { y: y(l.vals[n - 1]), l: l }; }).sort(function (a, b) { return a.y - b.y; });
    for (var k = 1; k < ends.length; k++) if (ends[k].y - ends[k - 1].y < 22) ends[k].y = ends[k - 1].y + 22;
    lines.forEach(function (l, li) {
      var d = l.vals.map(function (v, i) { return (i ? "L" : "M") + x(i).toFixed(1) + " " + y(v).toFixed(1); }).join("");
      g += '<path d="' + d + '" fill="none" stroke="' + l.color + '" stroke-width="' + (li === 0 ? 4 : 3) + '" stroke-linejoin="round" stroke-linecap="round"' + (l.dash ? ' stroke-dasharray="7 6"' : "") + "/>";
      g += '<circle cx="' + x(n - 1) + '" cy="' + y(l.vals[n - 1]) + '" r="5" fill="' + l.color + '"/>';
    });
    ends.forEach(function (e) { g += '<text class="endlab" x="' + (W - R + 10) + '" y="' + (e.y + 5) + '" fill="' + e.l.color + '">' + shortMoney(e.l.vals[n - 1]) + "</text>"; });
    g += "</svg>";
    var legend = '<ul class="legend">' + lines.map(function (l) { return '<li><span class="lg-swatch' + (l.dash ? " dash" : "") + '" style="--c:' + l.color + '"></span>' + esc(l.name) + "</li>"; }).join("") + "</ul>";
    var rows = "";
    for (var j = 0; j < n; j++) rows += "<tr><th scope=\"row\">" + (j === 0 ? "Start of " + y0 : "End of " + (y0 - 1 + j)) + "</th>" + lines.map(function (l) { return "<td>" + money(l.vals[j]) + "</td>"; }).join("") + "</tr>";
    var table = '<details class="chart-data"><summary>Show the numbers</summary><div class="table-scroll"><table class="stat-table"><thead><tr><th scope="col">Year</th>' +
      lines.map(function (l) { return '<th scope="col">' + esc(l.name) + "</th>"; }).join("") + "</tr></thead><tbody>" + rows + "</tbody></table></div></details>";
    el.innerHTML = legend + g + table;
  }

  function statTable(el, cols, start) {
    var rowDefs = [
      ["Average yearly growth", function (s) { return "<strong>" + pct(s.cagr, 1) + "</strong>"; }],
      [money(start) + " at the start became", function (s) { return money(start * s.total); }],
      ["Best year", function (s) { return pct(s.best.r, 1, true) + ' <span class="muted-inline">(' + s.best.y + ")</span>"; }],
      ["Worst year", function (s) { return '<span class="neg">' + pct(s.worst.r, 1, true) + '</span> <span class="muted-inline">(' + s.worst.y + ")</span>"; }],
      ["Years that lost money", function (s) { return s.down + " of " + s.n; }],
      ["Biggest drop from a high point", function (s) { return s.maxDD < 0 ? '<span class="neg">' + pct(s.maxDD, 0) + "</span>" : "None at year-end"; }],
    ];
    var extra = cols.some(function (c) { return c.access; });
    var h = '<thead><tr><th scope="col"><span class="sr-only">Measure</span></th>' + cols.map(function (c) { return '<th scope="col"><span class="dot" style="background:' + c.color + '"></span>' + esc(c.name) + "</th>"; }).join("") + "</tr></thead><tbody>";
    rowDefs.forEach(function (rd) { h += '<tr><th scope="row">' + rd[0] + "</th>" + cols.map(function (c) { return "<td>" + rd[1](c.s) + "</td>"; }).join("") + "</tr>"; });
    if (extra) {
      h += '<tr><th scope="row">When you can get your money</th>' + cols.map(function (c) { return "<td>" + esc(c.access || "") + "</td>"; }).join("") + "</tr>";
      h += '<tr><th scope="row">What it owns</th>' + cols.map(function (c) { return "<td>" + esc(c.owns || "") + "</td>"; }).join("") + "</tr>";
    }
    el.innerHTML = h + "</tbody>";
  }

  // ---------- Portfolio page ----------
  var pfYears = 20;
  function renderPortfolio() {
    var h = getHoldings(), sum = summarize(h), total = sum.total;
    $("#sum-total").textContent = money(total);
    $("#sum-liquid").textContent = money(sum.liquid);
    $("#sum-liquid-sub").textContent = total ? pct(sum.liquid / total, 0) + " of your money" : "";
    var fee = +$("#fee").value / 100;
    $("#fee-out").textContent = (fee * 100).toFixed(2) + "%";
    $("#sum-fee").textContent = money(total * fee);

    // Mix bar + groups
    $("#mix-bar").innerHTML = h.map(function (x) { return '<span style="flex:' + x.amt + ";background:" + A[x.key].color + '"></span>'; }).join("");
    var order = ["Stocks", "Bonds", "Cash", "Other", "Private markets"];
    $("#mix-groups").innerHTML = order.filter(function (g) { return sum.groups[g]; }).map(function (g) {
      return '<span class="mg"><strong>' + pct(sum.groups[g] / total, 0) + "</strong> " + g + "</span>";
    }).join("");

    // Holdings table (rebuilt only when not typing in it)
    var body = $("#holdings-body");
    if (!body.contains(document.activeElement) || document.activeElement.tagName === "BUTTON") {
      body.innerHTML = h.map(function (x, i) {
        var a = A[x.key];
        return '<tr data-i="' + i + '"><th scope="row"><span class="dot" style="background:' + a.color + '" aria-hidden="true"></span>' +
          '<select aria-label="Investment ' + (i + 1) + '" data-f="key">' + B.assets.map(function (o) { return '<option value="' + o.key + '"' + (o.key === x.key ? " selected" : "") + ">" + esc(o.name) + "</option>"; }).join("") + "</select>" +
          '<span class="h-example">e.g. ' + esc(a.example) + "</span></th>" +
          '<td data-label="Amount"><span class="money-input"><span aria-hidden="true">$</span><input inputmode="numeric" data-f="amt" aria-label="Amount for investment ' + (i + 1) + '" value="' + Math.round(x.amt).toLocaleString("en-US") + '"></span></td>' +
          '<td data-label="Share">' + (total ? pct(x.amt / total, 0) : "") + "</td>" +
          '<td data-label="When you can withdraw"' + (a.days > 7 ? ' class="warn-cell"' : "") + ">" + esc(a.access) + "</td>" +
          '<td data-label="What it owns">' + esc(a.owns) + ({ private_re: " <a class=\"lbl-link\" href=\"#label/breit\">See a label</a>", sp500: " <a class=\"lbl-link\" href=\"#label/index\">See a label</a>" }[x.key] || "") + "</td>" +
          '<td><button type="button" class="icon-btn" data-remove="' + i + '" aria-label="Remove ' + esc(a.name) + '">\u00d7</button></td></tr>';
      }).join("");
    }

    // Performance
    var ms = mixStats(sum, pfYears), ss = assetStats("sp500", pfYears), y0 = END - pfYears + 1;
    var m20 = mixStats(sum, 20);
    $("#sum-cagr").textContent = pct(m20.cagr, 1);
    $("#sum-cagr-sub").textContent = "Worst year: " + pct(m20.worst.r, 0) + " (" + m20.worst.y + ")";
    $("#pf-title").textContent = "Your " + money(total) + ", held for the last " + pfYears + " years (" + y0 + "\u2013" + END + "), would have become about " + money(total * ms.total) + ".";
    var start = total;
    lineChart($("#pf-chart"), y0, [
      { name: "Your mix", color: "#0CA678", vals: ms.growth.map(function (g) { return g * start; }) },
      { name: "All in large U.S. stocks", color: "#5B3FE0", dash: true, vals: ss.growth.map(function (g) { return g * start; }) },
    ], "Growth of your mix compared with large U.S. stocks, " + y0 + " to " + END);
    statTable($("#pf-table"), [
      { name: "Your mix", color: "#0CA678", s: ms },
      { name: "All in large U.S. stocks", color: "#5B3FE0", s: ss },
    ], start);
    $("#pf-note").textContent = (sum.noHist ? "Your " + money(sum.noHist) + " in a private fund has no public year-by-year price history, so the history uses the rest of your mix. " : "") +
      "Shows what today's mix would have done; fees and taxes not included. Source: NYU Stern annual returns.";

    renderSignals(h, sum, fee);
  }

  function signalsFor(h, sum, fee) {
    var out = [], total = sum.total, w = sum.weights;
    if (!total) return out;
    var share = function (k) { return (w[k] || 0) / total; };
    var groupShare = function (g) { return (sum.groups[g] || 0) / total; };
    var m20 = mixStats(sum, 20);

    // 1. History in dollars
    out.push({ tone: "info", title: "Your mix's worst year in the last 20: " + m20.worst.y,
      body: "This mix would have changed by " + pct(m20.worst.r, 0, true) + " that year. On today's " + money(total) + ", that would be " + (m20.worst.r < 0 ? "a drop of about " : "a gain of about ") + money(Math.abs(total * m20.worst.r)) +
        ". It also had " + m20.down + " losing year" + (m20.down === 1 ? "" : "s") + " out of 20. Knowing this ahead of time makes it easier not to panic." });

    // 2. Concentration
    var lg = sum.largest;
    if (share(lg) >= 0.5) {
      var ls = A[lg].series ? assetStats(lg, 20) : null;
      out.push({ tone: "watch", title: pct(share(lg), 0) + " of your money is in one place",
        body: A[lg].name + " holds more than half your portfolio." + (ls ? " Its own worst year in the last 20 was " + ls.worst.y + " (" + pct(ls.worst.r, 0, true) + ")." : "") +
          " Spreading money across different kinds of investments means one bad year hurts less." });
    } else if (Object.keys(sum.groups).length >= 3) {
      out.push({ tone: "good", title: "Your money is spread across " + Object.keys(sum.groups).length + " kinds of investment",
        body: "No single investment is more than half your portfolio, so one bad year in one area has a smaller effect on the whole." });
    }

    // 3. Access
    var locked = total - sum.liquid;
    if (w.private_re) {
      out.push({ tone: "watch", title: money(w.private_re) + " is in a fund with withdrawal limits",
        body: "Private real estate funds usually let everyone together withdraw only a small share each month or quarter. In 2022\u201324, investors in Blackstone's BREIT got only part of their requests for 15 months. Keep money you may need soon somewhere you can reach.",
        link: ["How withdrawal limits work", "#access"] });
    } else if (locked > 0) {
      out.push({ tone: "info", title: money(locked) + " would take more than a week to reach", body: "Some of what you own takes weeks or longer to turn into cash. That is fine for long-term money, not for emergencies." });
    }

    // 4. Rates trend
    var bonds = share("tbond") + share("corp");
    if (bonds > 0) {
      out.push({ tone: "info", title: "Interest rates are rising, which matters for your bonds",
        body: "The Fed raised rates on Sept. 16, 2026. When rates rise, existing bonds usually lose value: when rates rose quickly in 2022, 10-year Treasury bonds fell " + pct(r("tbond", 2022), 1) + " and corporate bonds " + pct(r("corp", 2022), 1) + ". New bonds bought later pay more, though.",
        link: ["Compare bonds and cash", "#research"] });
    }
    // 5. Cash vs inflation
    if (share("cash") >= 0.25) {
      var c30 = assetStats("cash", 30), s30 = assetStats("sp500", 30);
      out.push({ tone: share("cash") >= 0.5 ? "watch" : "info", title: pct(share("cash"), 0) + " is in cash",
        body: "Cash is steady and easy to reach, and it paid " + pct(r("cash", END), 1) + " in " + END + ". But inflation is 3.4% (August 2026), so cash is barely keeping up. Over 30 years cash grew " + pct(c30.cagr, 1) + " a year, versus " + pct(s30.cagr, 1) + " for large U.S. stocks, with far fewer bad years." });
    }
    // 6. Hot streaks
    if (w.gold) out.push({ tone: "watch", title: "Gold just had its best year since 1979",
      body: "Gold rose " + pct(r("gold", 2025), 0) + " in 2025. Big jumps can reverse: after rising " + pct(r("gold", 1979), 0) + " in 1979, gold fell " + pct(r("gold", 1981), 0) + " in 1981." });
    if (groupShare("Stocks") >= 0.6) out.push({ tone: "info", title: "Stocks have had three strong years in a row",
      body: "Large U.S. stocks returned " + pct(r("sp500", 2023), 0, true) + ", " + pct(r("sp500", 2024), 0, true) + " and " + pct(r("sp500", 2025), 0, true) + " from 2023 to 2025. Strong runs don't predict the next year: the same stocks fell " + pct(r("sp500", 2022), 0) + " in 2022." });

    // Small amounts
    if (total < 25000) {
      var wk = contribOutcomes(sum.weights, 25, 20), hasHist = Object.keys(sum.weights).some(function (k) { return A[k].series; });
      if (hasHist) out.push({ tone: "good", title: "Small, steady amounts add up",
        body: "If you added $25 a week to this same mix for 20 years, you'd put in " + money(wk.put) + ". Across every 20-year stretch since 1928, the typical result was about " + money(wk.typical) + " (worst " + money(wk.worst) + ", best " + money(wk.best) + ")." ,
        link: ["Try other amounts", "#start"] });
    }

    // 7. Fees
    if (fee > 0) {
      var g = 0.06, a = total * Math.pow(1 + g, 20), b = total * Math.pow((1 + g) * (1 - fee), 20);
      out.push({ tone: "info", title: "Your fees cost about " + money(total * fee) + " this year",
        body: "At " + (fee * 100).toFixed(2) + "% a year, and assuming 6% yearly growth, fees would cost about " + money(a - b) + " over 20 years, including the growth that money would have earned. Always ask for fees in dollars.",
        link: ["Try the fee calculator", "#learn/fees-in-dollars"] });
    }
    return out;
  }
  function renderSignals(h, sum, fee) {
    $("#signals").innerHTML = signalsFor(h, sum, fee).map(function (s) {
      return '<li class="signal sig-' + s.tone + '"><span class="sig-tag">' + { info: "Good to know", watch: "Worth a look", good: "Working well" }[s.tone] +
        "</span><h3>" + esc(s.title) + "</h3><p>" + esc(s.body) + "</p>" + (s.link ? '<a href="' + s.link[1] + '">' + esc(s.link[0]) + " \u2192</a>" : "") + "</li>";
    }).join("");
  }

  function bindPortfolio() {
    var body = $("#holdings-body");
    body.addEventListener("change", function (e) {
      var tr = e.target.closest("tr"); if (!tr) return;
      var h = getHoldings(), i = +tr.dataset.i;
      if (e.target.dataset.f === "key") h[i].key = e.target.value;
      if (e.target.dataset.f === "amt") h[i].amt = Math.max(0, parseMoney(e.target.value));
      setHoldings(h); e.target.blur(); renderPortfolio(); clearAI("#pf-ai");
    });
    body.addEventListener("keydown", function (e) { if (e.key === "Enter" && e.target.dataset.f === "amt") e.target.dispatchEvent(new Event("change", { bubbles: true })); });
    body.addEventListener("click", function (e) {
      var b = e.target.closest("[data-remove]"); if (!b) return;
      var h = getHoldings(); h.splice(+b.dataset.remove, 1);
      if (!h.length) h = [{ key: "cash", amt: 1000 }];
      setHoldings(h); renderPortfolio(); clearAI("#pf-ai"); $("#add-holding").focus();
    });
    $("#add-holding").addEventListener("click", function () {
      var h = getHoldings(); h.push({ key: "sp500", amt: 5000 }); setHoldings(h); renderPortfolio(); clearAI("#pf-ai");
      var sel = $$("#holdings-body select"); if (sel.length) sel[sel.length - 1].focus();
    });
    $("#preset").addEventListener("change", function (e) {
      var v = e.target.value; if (v === "") return;
      var h = v === "demo" ? demoHoldings() : B.profile.presets[+v].holdings.map(function (x) { return { key: x[0], amt: x[1] }; });
      setHoldings(h); renderPortfolio(); clearAI("#pf-ai"); e.target.value = "";
    });
    $("#fee").addEventListener("input", function () { renderPortfolio(); });
    periodGroup("#pf-period", function (y) { pfYears = y; renderPortfolio(); });
  }

  function periodGroup(sel, fn) {
    $$(sel + " button").forEach(function (b) {
      b.addEventListener("click", function () {
        $$(sel + " button").forEach(function (x) { x.setAttribute("aria-pressed", x === b ? "true" : "false"); });
        fn(+b.dataset.years);
      });
    });
  }

  // ---------- Research page ----------
  var picked = ["sp500", "tbond", "cash"], cmpYears = 20, researchReady = false;
  function renderCompare() {
    $$("#cmp-pick .pick-btn").forEach(function (b) { b.setAttribute("aria-pressed", picked.indexOf(b.dataset.asset) >= 0 ? "true" : "false"); });
    var y0 = END - cmpYears + 1;
    var cols = picked.map(function (k) { var a = A[k]; return { key: k, name: a.name, color: a.color, s: assetStats(k, cmpYears), access: a.access, owns: a.owns }; });
    $("#cmp-title").textContent = "What $10,000 would have become, " + y0 + "\u2013" + END;
    lineChart($("#cmp-chart"), y0, cols.map(function (c) { return { name: c.name, color: c.color, vals: c.s.growth.map(function (g) { return g * 10000; }) }; }),
      "Growth of $10,000 in " + cols.map(function (c) { return c.name; }).join(", ") + ", " + y0 + " to " + END);
    statTable($("#cmp-table"), cols, 10000);
    clearAI("#cmp-ai");
  }
  function renderWhatIf() {
    var base = getHoldings(), key = $("#wi-asset").value, amt = Math.max(0, parseMoney($("#wi-amount").value));
    var after = base.concat([{ key: key, amt: amt }]);
    var sb = summarize(base), sa = summarize(after);
    $("#wi-base").textContent = "Starting from " + (APP.store.get("holdings", null) ? "your portfolio" : "the demo portfolio") + " (" + money(sb.total) + "). Using the last 20 years of real returns.";
    var b20 = mixStats(sb, 20), a20 = mixStats(sa, 20);
    function card(label, before, afterV, better, note) {
      var cls = better == null ? "" : better ? " up" : " down";
      return '<div class="wi-card' + cls + '"><p class="wi-label">' + label + '</p><p class="wi-vals"><span>' + before + '</span><span class="wi-arrow" aria-label="becomes">\u2192</span><strong>' + afterV + "</strong></p>" + (note ? '<p class="small">' + note + "</p>" : "") + "</div>";
    }
    var stB = (sb.groups.Stocks || 0) / sb.total, stA = (sa.groups.Stocks || 0) / sa.total;
    var lqB = sb.liquid / sb.total, lqA = sa.liquid / sa.total;
    var html = card("Average yearly growth", pct(b20.cagr, 1), pct(a20.cagr, 1), Math.abs(a20.cagr - b20.cagr) < 0.0005 ? null : a20.cagr > b20.cagr) +
      card("Worst single year", pct(b20.worst.r, 1) + " (" + b20.worst.y + ")", pct(a20.worst.r, 1) + " (" + a20.worst.y + ")", Math.abs(a20.worst.r - b20.worst.r) < 0.0005 ? null : a20.worst.r > b20.worst.r) +
      card("Share you could reach within a week", pct(lqB, 0), pct(lqA, 0), Math.abs(lqA - lqB) < 0.005 ? null : lqA > lqB) +
      card("Share in stocks", pct(stB, 0), pct(stA, 0), null, "Neither better nor worse: more stocks usually means bigger ups and downs.");
    var a = A[key];
    var note = a.series ? "" : '<p class="wi-note">' + esc(a.name) + " has no public year-by-year price history, so growth and worst year above leave it out. What changes for sure is access: " + esc(a.access) + ".</p>";
    $("#wi-out").innerHTML = '<div class="wi-grid">' + html + "</div>" + note + '<p class="small">Green means the change moved in a steadier or stronger direction over this period; orange means the opposite. It is history, not a forecast or a recommendation.</p>';
  }
  function renderHeat() {
    var years = []; for (var y = END - 9; y <= END; y++) years.push(y);
    var leaders = {};
    var head = '<thead><tr><th scope="col">Investment</th>' + years.map(function (y) { return '<th scope="col">' + y + "</th>"; }).join("") + "</tr></thead>";
    var best = {}; years.forEach(function (y) { var m = null; CHARTABLE.forEach(function (k) { if (m == null || r(k, y) > r(m, y)) m = k; }); best[y] = m; leaders[m] = 1; });
    var rows = CHARTABLE.map(function (k) {
      return '<tr><th scope="row"><span class="dot" style="background:' + A[k].color + '"></span>' + esc(A[k].short) + "</th>" + years.map(function (y) {
        var v = r(k, y), lvl = v >= 0.2 ? "p3" : v >= 0.08 ? "p2" : v >= 0 ? "p1" : v > -0.1 ? "n1" : "n2";
        return '<td class="h-' + lvl + (best[y] === k ? " h-best" : "") + '">' + pct(v, 0, true) + (best[y] === k ? '<span class="sr-only"> (best that year)</span>' : "") + "</td>";
      }).join("") + "</tr>";
    }).join("");
    $("#heat").innerHTML = "<caption class=\"sr-only\">Yearly returns by investment, " + years[0] + " to " + END + "</caption>" + head + "<tbody>" + rows + "</tbody>";
    $("#heat-take").textContent = "In the last 10 years, " + Object.keys(leaders).length + " different investments took first place (marked with a star). Nobody reliably knows which one leads next year, which is why spreading your money out matters.";
  }
  function initResearch() {
    if (researchReady) return; researchReady = true;
    $$("#cmp-pick .pick-btn").forEach(function (b) {
      b.addEventListener("click", function () {
        var k = b.dataset.asset, i = picked.indexOf(k), note = $("#cmp-note");
        note.textContent = "";
        if (i >= 0) { if (picked.length > 1) picked.splice(i, 1); else { note.textContent = "Keep at least one selected."; return; } }
        else if (picked.length >= 3) { note.textContent = "You can compare up to three. Unselect one first."; return; }
        else picked.push(k);
        renderCompare();
      });
    });
    periodGroup("#cmp-period", function (y) { cmpYears = y; renderCompare(); });
    $("#wi-asset").value = "corp";
    $("#wi-asset").addEventListener("change", renderWhatIf);
    $("#wi-amount").addEventListener("change", function () { $("#wi-amount").value = Math.round(parseMoney($("#wi-amount").value)).toLocaleString("en-US"); renderWhatIf(); });
    $("#wi-amount").addEventListener("keydown", function (e) { if (e.key === "Enter") $("#wi-amount").dispatchEvent(new Event("change")); });
    renderCompare(); renderWhatIf(); renderHeat();
  }

  // ---------- AI (Claude, via the published page's `sample` capability) ----------
  var sample = null, canTools = false;
  var RULES = [
    "You are the Bridge guide inside Blackstone Bridge, an investor-education app. Most users are Gen Z or young millennials who have never invested, often starting with small amounts ($5 to $100 a week), and who distrust hype and finance influencers.",
    "Education, not manipulation: explain clearly and honestly. Never tell the user to buy, sell or hold a specific investment, never predict prices, and never promise returns. You may explain trade-offs and suggest questions to ask a licensed adviser.",
    "Use ONLY the data given below or returned by tools. When you cite a number, say what period it covers. If the data can't answer, say so plainly.",
    "Write in plain, friendly, direct English (no slang, no hype) at about an 8th-grade reading level. Show how small, regular amounts work when relevant. Explain any financial term in the same sentence. Use dollars, not only percentages, when the user's own money is involved.",
    "Keep answers short: 2 to 4 short paragraphs or a few bullet points, under 180 words. No headings, no tables.",
    "Never ask for passwords, PINs, one-time codes or account numbers. If the user describes a pitch with guaranteed high returns, pressure to act fast, or payment in crypto or gift cards, warn that these are scam signs and point them to FINRA BrokerCheck.",
    "If the user asks about the investment label they are viewing, explain it using the label data, and point out anything the document does not say.",
    "If asked about something unrelated to money and investing, gently steer back.",
  ].join("\n");

  function contextText() {
    var h = getHoldings(), sum = summarize(h), total = sum.total, lines = [];
    lines.push("TODAY: September 2026. Market history covers " + START + "\u2013" + END + " (source: NYU Stern, Damodaran, annual total returns, before fees and taxes).");
    lines.push("\nUSER PORTFOLIO (" + (APP.store.get("holdings", null) ? "their own entries" : "demo account") + "), total " + money(total) + ":");
    h.forEach(function (x) { var a = A[x.key]; lines.push("- " + a.name + ": " + money(x.amt) + " (" + pct(x.amt / total, 0) + "). Access: " + a.access + ". Owns: " + a.owns + (a.series ? "" : " No public yearly price history.")); });
    lines.push("Could reach within a week: " + money(sum.liquid) + ". Yearly fee setting: " + $("#fee").value + "%.");
    [5, 10, 20, 30].forEach(function (y) {
      var s = mixStats(sum, y);
      lines.push("Mix over last " + y + " yrs: avg " + pct(s.cagr, 1) + "/yr, best " + pct(s.best.r, 1) + " (" + s.best.y + "), worst " + pct(s.worst.r, 1) + " (" + s.worst.y + "), " + s.down + " losing years, biggest drop from a high " + pct(s.maxDD, 0) + ".");
    });
    lines.push("\nSIGNALS SHOWN TO USER:");
    signalsFor(h, sum, +$("#fee").value / 100).forEach(function (s) { lines.push("- " + s.title + ": " + s.body); });
    lines.push("\nINVESTMENTS AVAILABLE (history stats):");
    CHARTABLE.forEach(function (k) {
      var a = A[k], s10 = assetStats(k, 10), s30 = assetStats(k, 30);
      var last5 = []; for (var y = END - 4; y <= END; y++) last5.push(y + ": " + pct(r(k, y), 1));
      lines.push("- " + a.name + " [" + k + "] (" + a.owns + " Access: " + a.access + "). 10-yr avg " + pct(s10.cagr, 1) + ", worst " + pct(s10.worst.r, 1) + " (" + s10.worst.y + "). 30-yr avg " + pct(s30.cagr, 1) + ", worst " + pct(s30.worst.r, 1) + " (" + s30.worst.y + "), losing years " + s30.down + "/30. Last 5 yrs: " + last5.join(", ") + ".");
    });
    lines.push("- " + A.private_re.name + " [private_re] (" + A.private_re.owns + " Access: " + A.private_re.access + "). No public yearly price history. Fact: BREIT (Blackstone's non-traded REIT) limited withdrawals Nov 2022\u2013Feb 2024 when requests exceeded 2%/month or 5%/quarter; requests peaked at $5.3B in Jan 2023; more than $15B was returned over those 15 months, and 100% of requests were paid again from Feb 2024.");
    lines.push("\nCURRENT CONDITIONS:");
    B.snapshot.forEach(function (n) { lines.push("- " + n.label + ": " + n.value + " (" + n.when + "). " + n.means); });
    lines.push("- Investment scams cost Americans $7.9B in 2025 (FTC), often starting on social media.");
    if (window.BridgeLabels) { var lt = window.BridgeLabels.summaryText(); if (lt) lines.push("\nINVESTMENT LABEL THE USER IS VIEWING (built from the document they pasted or a sample; dollar figures computed by the app):\n" + lt); }
    return lines.join("\n");
  }

  function mdLite(t) {
    var html = "", list = false;
    esc(t).split(/\n/).forEach(function (line) {
      var l = line.trim().replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
      if (/^[-*\u2022]\s+/.test(l)) { if (!list) { html += "<ul>"; list = true; } html += "<li>" + l.replace(/^[-*\u2022]\s+/, "") + "</li>"; return; }
      if (list) { html += "</ul>"; list = false; }
      if (l) html += "<p>" + l.replace(/^#+\s*/, "") + "</p>";
    });
    return html + (list ? "</ul>" : "");
  }
  function errCopy(code) {
    return code === "rate_limited" ? "Too many questions at once. Please wait a minute and try again."
      : code === "refused" ? "I can't help with that one. Try asking it a different way."
      : code === "session_expired" ? "Please sign in to Claude again, then retry."
      : "Something went wrong reaching the guide. Please try again.";
  }
  function isOff(code) { return ["not_granted", "sampling_disabled", "not_declared", "capability_disabled", "capability_removed"].indexOf(code) >= 0; }
  function disableAI() {
    sample = null; APP.aiAnswer = null;
    $$("[data-ai]").forEach(function (p) { p.hidden = true; });
    var sub = $("#chat-sub"); if (sub) sub.textContent = "Plain answers from our guide. A licensed person is one tap away.";
  }
  function clearAI(sel) { var el = $(sel); if (el) el.innerHTML = ""; }

  var tools = [
    { name: "what_if_add", description: "Adds an amount of one investment to the user's portfolio hypothetically and returns before/after 20-year stats (avg yearly growth, worst year, share reachable within a week). Use for 'what if I add/put $X in Y' questions.",
      inputSchema: { type: "object", properties: { asset: { type: "string", enum: B.assets.map(function (a) { return a.key; }) }, amount: { type: "number" } }, required: ["asset", "amount"] },
      execute: function (inp) {
        var k = String(inp.asset); if (!A[k]) throw new Error("Unknown asset " + k);
        var base = getHoldings(), after = base.concat([{ key: k, amt: Math.max(0, Number(inp.amount) || 0) }]);
        var sb = summarize(base), sa = summarize(after), b = mixStats(sb, 20), a = mixStats(sa, 20);
        return { before: { total: Math.round(sb.total), avg: pct(b.cagr, 2), worst: pct(b.worst.r, 1) + " in " + b.worst.y, reachable_in_week: pct(sb.liquid / sb.total, 0) },
          after: { total: Math.round(sa.total), avg: pct(a.cagr, 2), worst: pct(a.worst.r, 1) + " in " + a.worst.y, reachable_in_week: pct(sa.liquid / sa.total, 0) },
          note: A[k].series ? "" : "This asset has no public yearly history; growth/worst exclude it." };
      } },
    { name: "asset_history", description: "Returns yearly total returns for one investment between two years (inclusive, " + START + "-" + END + ", max 40 years) plus average growth. Use for questions about a specific year, decade or period.",
      inputSchema: { type: "object", properties: { asset: { type: "string", enum: CHARTABLE }, from: { type: "integer" }, to: { type: "integer" } }, required: ["asset", "from", "to"] },
      execute: function (inp) {
        var k = String(inp.asset); if (!A[k] || !A[k].series) throw new Error("No history for " + k);
        var to = Math.min(END, Math.max(START, Number(inp.to) || END)), from = Math.max(START, Math.min(to, Number(inp.from) || to - 9));
        if (to - from > 39) from = to - 39;
        var yr = {}; for (var y = from; y <= to; y++) yr[y] = pct(r(k, y), 1);
        return { asset: A[k].name, years: yr, avg_yearly: pct(stats(mixReturns(one(k), from, to), from).cagr, 2) };
      } },
  ];

  var turns = [];
  function aiChat(q, log) {
    var bubble = document.createElement("div"); bubble.className = "msg msg-bot";
    var body = document.createElement("div"); body.className = "ai-text"; body.innerHTML = '<p class="thinking">Thinking\u2026</p>';
    var stop = document.createElement("button"); stop.type = "button"; stop.className = "stop-btn"; stop.textContent = "Stop";
    bubble.appendChild(body); bubble.appendChild(stop); log.appendChild(bubble); log.scrollTop = log.scrollHeight;
    var ctl = new AbortController(); stop.onclick = function () { ctl.abort(); };
    turns.push({ role: "user", content: q }); if (turns.length > 8) turns = turns.slice(-8);
    var opts = { cache: false, signal: ctl.signal, onText: function (u) { body.innerHTML = mdLite(u.text); log.scrollTop = log.scrollHeight; } };
    if (canTools) { delete opts.cache; opts.tools = tools.map(function (t) { return { name: t.name, description: t.description, inputSchema: t.inputSchema, execute: function (i) { body.innerHTML = '<p class="thinking">Checking the data\u2026</p>'; return t.execute(i); } }; }); }
    var input = [{ role: "user", content: RULES + "\n\nDATA:\n" + contextText() + "\n\nThe conversation follows." }].concat(turns);
    sample(input, opts).then(function (res) {
      body.innerHTML = mdLite(res.text); turns.push({ role: "assistant", content: res.text });
      stop.remove(); addLinks(bubble, q);
      var src = document.createElement("p"); src.className = "ai-src"; src.textContent = "AI answer using your portfolio and NYU Stern market data. Education only, not advice.";
      bubble.appendChild(src); log.scrollTop = log.scrollHeight;
    }).catch(function (e) {
      stop.remove(); turns.pop();
      if (e && isOff(e.code)) { bubble.remove(); disableAI(); APP.ruleAnswer(q); return; }
      if (e && e.code === "cancelled") { body.innerHTML = e.text ? mdLite(e.text) + '<p class="small">Stopped.</p>' : '<p class="small">Stopped.</p>'; return; }
      body.innerHTML = (e && e.text ? mdLite(e.text) : "") + "<p>" + esc(errCopy(e && e.code)) + "</p>";
    });
  }
  function addLinks(bubble, q) {
    var t = q.toLowerCase(), best = null, bestLen = 0;
    B.chat.topics.forEach(function (topic) { topic.keys.forEach(function (k) {
      var re = new RegExp("(^|[^a-z])" + k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
      if (re.test(t) && k.length > bestLen && topic.go) { best = topic; bestLen = k.length; }
    }); });
    if (/portfolio|my money|what i own|my mix/.test(t)) best = { go: [["See my portfolio", "#profile"]] };
    if (/compare|versus| vs |better/.test(t)) best = { go: [["Compare investments", "#research"]] };
    if (!best) return;
    var row = document.createElement("div"); row.className = "msg-actions";
    best.go.forEach(function (g) { row.appendChild(APP.linkBtn(g[0], g[1])); });
    bubble.appendChild(row);
  }

  function explain(btn, out, prompt) {
    if (!sample) return;
    var ctl = new AbortController();
    btn.disabled = true; out.innerHTML = '<p class="thinking">Thinking\u2026 this can take up to a minute.</p>';
    var stop = document.createElement("button"); stop.type = "button"; stop.className = "btn btn-quiet"; stop.textContent = "Stop";
    stop.onclick = function () { ctl.abort(); }; btn.after(stop);
    sample(RULES + "\n\nDATA:\n" + contextText() + "\n\nTASK:\n" + prompt, { signal: ctl.signal, onText: function (u) { out.innerHTML = mdLite(u.text); } })
      .then(function (res) { out.innerHTML = mdLite(res.text) + '<p class="ai-src">Written by AI from the numbers on this page. Education only, not advice.</p>'; })
      .catch(function (e) {
        if (e && isOff(e.code)) { out.innerHTML = ""; disableAI(); return; }
        out.innerHTML = e && e.code === "cancelled" ? (e.text ? mdLite(e.text) : "") : (e && e.text ? mdLite(e.text) : "") + "<p>" + esc(errCopy(e && e.code)) + "</p>";
      })
      .then(function () { btn.disabled = false; stop.remove(); });
  }

  function initAI() {
    if (!window.claude || typeof window.claude.use !== "function") return;
    window.claude.use("sample").then(function (fn) {
      if (!fn) return;
      sample = fn;
      if (fn.limits) fn.limits().then(function (l) { canTools = !!(l && l.tools); }).catch(function () {});
      $$("[data-ai]").forEach(function (p) { p.hidden = false; });
      APP.aiAnswer = aiChat;
      var sub = $("#chat-sub"); if (sub) sub.textContent = "AI answers from your portfolio and real market data. A licensed person is one tap away.";
    }).catch(function () {});
    $("#pf-explain").addEventListener("click", function () {
      explain($("#pf-explain"), $("#pf-ai"),
        "Explain this person's portfolio to them in plain English. Cover: what they own and how spread out it is; how this mix has behaved over the last 20 years, including its worst year in dollars; how easily they can reach their money; one thing about current conditions (rates, inflation) that affects them. End with two good questions they could ask a licensed adviser. Under 220 words, short paragraphs or bullets.");
    });
    $("#cmp-explain").addEventListener("click", function () {
      var y0 = END - cmpYears + 1;
      explain($("#cmp-explain"), $("#cmp-ai"),
        "The user is comparing: " + picked.map(function (k) { return A[k].name; }).join(", ") + " over " + y0 + "\u2013" + END + " (" + cmpYears + " years). Using the data, explain in plain English how they differ in growth, bad years and access to money, what kind of goal each tends to suit, and one thing current conditions mean for them. Do not recommend one. Under 200 words.");
    });
  }


  // ---------- Start small (Home) ----------
  // Adds the same amount every week, through every N-year stretch in history.
  var MIXES = { stocks: { sp500: 1 }, half: { sp500: 0.5, tbond: 0.5 }, cash: { cash: 1 } };
  function contribOutcomes(weights, weekly, years) {
    var c = weekly * 52, finals = [];
    for (var s0 = START; s0 + years - 1 <= END; s0++) {
      var rets = mixReturns(weights, s0, s0 + years - 1), v = 0;
      rets.forEach(function (x) { v = v * (1 + x) + c * (1 + x / 2); }); // contributions spread through the year
      finals.push(v);
    }
    finals.sort(function (a, b) { return a - b; });
    var put = c * years;
    return { put: put, worst: finals[0], best: finals[finals.length - 1], typical: finals[Math.floor(finals.length / 2)],
      losses: finals.filter(function (f) { return f < put; }).length, n: finals.length };
  }
  var stAmt = 10, stMix = "stocks";
  function renderStarter() {
    var years = +$("#st-years").value;
    $("#st-years-out").textContent = years;
    $("#st-n").textContent = years;
    $("#st-amt-h").textContent = "$" + stAmt;
    var o = contribOutcomes(MIXES[stMix], stAmt, years);
    $("#st-put").textContent = money(o.put);
    $("#st-typ").textContent = money(o.typical);
    $("#st-worst").textContent = money(o.worst);
    $("#st-best").textContent = money(o.best);
    var max = o.best;
    var fill = $("#st-range-fill");
    fill.style.left = (o.worst / max * 100) + "%"; fill.style.width = ((o.best - o.worst) / max * 100) + "%";
    $("#st-mark-in").style.left = Math.min(99, o.put / max * 100) + "%";
    var dot = $("#st-range .st-dot") || (function () { var d = document.createElement("span"); d.className = "st-dot"; $(".st-range").appendChild(d); return d; })();
    dot.style.left = (o.typical / max * 100) + "%";
    $("#st-loss").textContent = o.losses
      ? "Ended with less than you put in: " + o.losses + " of " + o.n + " past " + years + "-year stretches. The white line marks what you put in."
      : "Ended with more than you put in: all " + o.n + " past " + years + "-year stretches. The white line marks what you put in.";
    if (years >= 10) {
      var later = contribOutcomes(MIXES[stMix], stAmt, years - 5);
      $("#st-wait").textContent = "Waiting 5 years to start (same end date): typical result " + money(later.typical) + ", about " + money(o.typical - later.typical) + " less.";
    } else $("#st-wait").textContent = "";
  }
  function initStarter() {
    if (!$("#st-years")) return;
    $$("#st-amt button").forEach(function (b) { b.addEventListener("click", function () {
      stAmt = +b.dataset.v; $$("#st-amt button").forEach(function (x) { x.setAttribute("aria-pressed", x === b ? "true" : "false"); }); renderStarter(); }); });
    $$("#st-mix button").forEach(function (b) { b.addEventListener("click", function () {
      stMix = b.dataset.v; $$("#st-mix button").forEach(function (x) { x.setAttribute("aria-pressed", x === b ? "true" : "false"); }); renderStarter(); }); });
    $("#st-years").addEventListener("input", renderStarter);
    renderStarter();
  }

  // ---------- Wiring ----------
  bindPortfolio();
  initStarter();
  initAI();
  window.BridgeInsights = {
    renderPortfolio: renderPortfolio,
    onRoute: function (page) { if (page === "research") { initResearch(); renderWhatIf(); } }
  };
  var cur = (location.hash || "#start").slice(1).split("/")[0];
  window.BridgeInsights.onRoute(cur);
  if (cur === "profile" && APP.store.get("user", null)) renderPortfolio();
})();
