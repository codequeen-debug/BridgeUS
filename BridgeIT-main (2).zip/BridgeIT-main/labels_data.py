"""Sample documents and their pre-built investment labels.

The sample documents are short fact-sheet-style excerpts written by the Bridge
team from each fund's public terms (they are NOT verbatim filing text). Every
`q` (receipt) must appear word-for-word in its document; `check()` enforces it.
Percentages are numbers: 1.25 means 1.25%.
"""
import re

SAMPLES = [
  {
    "key": "breit", "chip": "Blackstone BREIT",
    "filing": "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=0001662972&type=424B3",
    "doc": """Blackstone Real Estate Income Trust (BREIT): key terms
Sample excerpt written from BREIT's public terms for this demo. Read the prospectus for full details.

BREIT is a non-traded real estate investment trust. It owns rental housing, industrial warehouses, data centers and other commercial real estate across the United States.

Shares are not listed on a stock exchange. BREIT offers to repurchase shares each month, but total repurchases are limited to 2% of NAV per month and 5% of NAV per quarter. If requests exceed these limits, each investor receives only part of their request. The board may modify or suspend the repurchase plan.

Shares held for less than one year are repurchased at 98% of NAV, which is a 2% early repurchase deduction.

BREIT pays its adviser a management fee of 1.25% of NAV per year. The adviser's affiliate also receives a performance participation equal to 12.5% of total return, subject to a 5% hurdle and a high water mark.

Class S shares may carry an upfront selling commission of up to 3.5% of the purchase price, plus an ongoing stockholder servicing fee of 0.85% of NAV per year.

NAV is calculated monthly. It relies on appraisals and estimates of property values rather than prices from a public market.

From November 2022 to February 2024, repurchase requests exceeded the limits, and investors received only part of what they asked for.

Real estate values can fall, the fund uses borrowed money, and distributions are not guaranteed.""",
    "label": {
      "name": "Blackstone Real Estate Income Trust (BREIT)", "kind": "Private real estate fund (non-traded REIT)",
      "summary": "A fund that owns U.S. buildings like apartments, warehouses and data centers. It isn't traded on an exchange, so getting your money out depends on the fund's monthly limits.",
      "owns": [{"t": "Apartments, warehouses, data centers and other U.S. commercial real estate.", "q": "It owns rental housing, industrial warehouses, data centers and other commercial real estate across the United States."}],
      "fees": {
        "yearly": [
          {"name": "Management fee", "pct": 1.25, "q": "BREIT pays its adviser a management fee of 1.25% of NAV per year."},
          {"name": "Servicing fee (Class S)", "pct": 0.85, "q": "plus an ongoing stockholder servicing fee of 0.85% of NAV per year"}],
        "performance": {"pct": 12.5, "hurdle": 5, "q": "The adviser's affiliate also receives a performance participation equal to 12.5% of total return, subject to a 5% hurdle and a high water mark."},
        "upfront": {"pct": 3.5, "note": "Up to, for Class S shares", "q": "Class S shares may carry an upfront selling commission of up to 3.5% of the purchase price"},
        "exit": {"pct": 2, "period": "within 1 year", "q": "Shares held for less than one year are repurchased at 98% of NAV, which is a 2% early repurchase deduction."}},
      "access": {"level": 1, "text": "Monthly, but all investors together can take out only 2% of the fund a month and 5% a quarter.",
        "items": [
          {"t": "Not on a stock exchange, so you can't just sell.", "q": "Shares are not listed on a stock exchange."},
          {"t": "Monthly limits: 2% of the fund a month, 5% a quarter.", "q": "BREIT offers to repurchase shares each month, but total repurchases are limited to 2% of NAV per month and 5% of NAV per quarter."},
          {"t": "If too many people ask, you get only part of your money.", "q": "If requests exceed these limits, each investor receives only part of their request."},
          {"t": "The board can change or pause withdrawals.", "q": "The board may modify or suspend the repurchase plan."},
          {"t": "This really happened for 15 months.", "q": "From November 2022 to February 2024, repurchase requests exceeded the limits, and investors received only part of what they asked for."}]},
      "pricing": [{"t": "Priced once a month from appraisals, not market trades.", "q": "It relies on appraisals and estimates of property values rather than prices from a public market."}],
      "risks": [
        {"t": "Property values can fall.", "q": "Real estate values can fall, the fund uses borrowed money, and distributions are not guaranteed."}],
      "flags": [],
      "questions": ["Which share class would I get, and what upfront and yearly fees apply to it?", "If withdrawals are limited again, how long might it take to get all my money?", "How are the appraisals done, and who checks them?"],
      "missing": ["Total yearly expenses beyond the fees listed (for example, fund operating costs)."]
    }
  },
  {
    "key": "bxpe", "chip": "Blackstone BXPE",
    "filing": "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=0001930054&type=10-K",
    "doc": """Blackstone Private Equity Strategies Fund (BXPE): key terms
Sample excerpt written from BXPE's public terms for this demo. Read the offering documents for full details.

BXPE is a perpetual-life private equity fund for eligible individual investors, launched on January 2, 2024. It invests mainly in privately negotiated, equity-oriented investments across corporate private equity, secondaries, opportunistic, growth and life sciences strategies.

Investors can subscribe monthly. Units are not listed on an exchange, and there is no public market for them.

The fund intends to offer to repurchase units each quarter, limited to 3% of the fund's NAV per quarter. Repurchases may be limited, suspended or modified at the fund's discretion. Units held for less than two years are subject to an early repurchase deduction.

The fund pays a management fee of 1.25% of NAV per year. A performance participation of 12.5% of total return is paid when total return exceeds a 5% annual hurdle.

Units are valued monthly at NAV, which is based on estimates of the value of private companies and may not match the price they could be sold for.

Private equity investments are illiquid, may use borrowed money, and can lose value. This fund is only suitable for investors who do not need quick access to their money.""",
    "label": {
      "name": "Blackstone Private Equity Strategies Fund (BXPE)", "kind": "Private equity fund (non-traded)",
      "summary": "A fund that buys stakes in private companies. Withdrawals are quarterly and capped, and selling within two years costs extra, but this excerpt doesn't say how much.",
      "owns": [{"t": "Stakes in private companies across several private equity strategies.", "q": "It invests mainly in privately negotiated, equity-oriented investments across corporate private equity, secondaries, opportunistic, growth and life sciences strategies."}],
      "fees": {
        "yearly": [{"name": "Management fee", "pct": 1.25, "q": "The fund pays a management fee of 1.25% of NAV per year."}],
        "performance": {"pct": 12.5, "hurdle": 5, "q": "A performance participation of 12.5% of total return is paid when total return exceeds a 5% annual hurdle."},
        "upfront": None,
        "exit": {"pct": None, "period": "within 2 years", "q": "Units held for less than two years are subject to an early repurchase deduction."}},
      "access": {"level": 2, "text": "Quarterly, and all investors together can take out only 3% of the fund a quarter.",
        "items": [
          {"t": "No public market, so you can't just sell.", "q": "Units are not listed on an exchange, and there is no public market for them."},
          {"t": "Quarterly limit: 3% of the fund.", "q": "The fund intends to offer to repurchase units each quarter, limited to 3% of the fund's NAV per quarter."},
          {"t": "Withdrawals can be limited or paused.", "q": "Repurchases may be limited, suspended or modified at the fund's discretion."},
          {"t": "Meant for money you won't need soon.", "q": "This fund is only suitable for investors who do not need quick access to their money."}]},
      "pricing": [{"t": "Valued monthly from estimates of private company values.", "q": "Units are valued monthly at NAV, which is based on estimates of the value of private companies and may not match the price they could be sold for."}],
      "risks": [{"t": "Hard to sell, may borrow money, and can lose value.", "q": "Private equity investments are illiquid, may use borrowed money, and can lose value."}],
      "flags": [],
      "questions": ["How much is the early repurchase deduction if I sell within two years?", "Are there upfront or yearly selling fees for the share class I'd buy?", "How often has the fund met all withdrawal requests?"],
      "missing": ["How big the early repurchase deduction is.", "Whether any upfront sales charges or servicing fees apply."]
    }
  },
  {
    "key": "index", "chip": "S&P 500 index fund",
    "filing": "https://www.investor.gov/introduction-investing/investing-basics/investment-products/mutual-funds-and-exchange-traded-1",
    "doc": """Sample S&P 500 Index Fund: key terms
Generic sample written for this demo, based on typical low-cost index funds.

The fund seeks to track the S&P 500 index, which includes 500 of the largest companies in the United States.

Expense ratio: 0.03% per year. There is no sales charge, and no purchase or redemption fees.

You can buy or sell shares on any business day at that day's closing NAV. NAV is calculated each business day from the market prices of the stocks the fund holds.

The fund's value rises and falls with the stock market. In 2008, the S&P 500 lost more than 36% of its value. The fund does not use borrowed money.""",
    "label": {
      "name": "Sample S&P 500 Index Fund", "kind": "Stock index fund (publicly traded)",
      "summary": "A low-cost fund that owns the 500 largest U.S. companies. You can sell any business day, but its value moves with the stock market.",
      "owns": [{"t": "Shares of the 500 largest U.S. companies.", "q": "The fund seeks to track the S&P 500 index, which includes 500 of the largest companies in the United States."}],
      "fees": {
        "yearly": [{"name": "Expense ratio", "pct": 0.03, "q": "Expense ratio: 0.03% per year."}],
        "performance": None,
        "upfront": {"pct": 0, "note": "None", "q": "There is no sales charge, and no purchase or redemption fees."},
        "exit": {"pct": 0, "period": "", "q": "There is no sales charge, and no purchase or redemption fees."}},
      "access": {"level": 0, "text": "Any business day.",
        "items": [{"t": "Sell any business day at that day's price.", "q": "You can buy or sell shares on any business day at that day's closing NAV."}]},
      "pricing": [{"t": "Priced daily from real market prices.", "q": "NAV is calculated each business day from the market prices of the stocks the fund holds."}],
      "risks": [{"t": "Moves with the stock market, including big drops.", "q": "In 2008, the S&P 500 lost more than 36% of its value."}],
      "flags": [],
      "questions": ["Is this fund available with no account fees at my brokerage?", "Can I set up automatic weekly investing?"],
      "missing": []
    }
  },
  {
    "key": "pitch", "chip": "Social media pitch",
    "filing": "",
    "doc": """I turned $500 into $12,000 in 3 weeks with my AI trading bot!! My VIP group gets GUARANTEED 3% daily returns with zero risk.

Only 20 spots left and the offer ends tonight! DM me to join.

Send your deposit in USDT or gift cards and I'll set up your account. Withdrawals open after 90 days once you unlock your profit tier.

This is private and insider-only, not available on any exchange. Trust me, my followers are all winning.""",
    "label": {
      "name": "\u201cVIP AI trading group\u201d post", "kind": "Unregistered offer on social media",
      "summary": "A post promising huge guaranteed returns, with payment in crypto or gift cards and locked withdrawals. It has the classic signs of an investment scam.",
      "owns": [],
      "fees": {"yearly": [], "performance": None, "upfront": None, "exit": None},
      "access": {"level": 3, "text": "Locked for 90 days, then only if you \u201cunlock\u201d a tier.",
        "items": [{"t": "Your money is locked, with conditions to get it back.", "q": "Withdrawals open after 90 days once you unlock your profit tier."}]},
      "pricing": [],
      "risks": [],
      "flags": [
        {"t": "Guaranteed high returns with no risk. Real investments never promise this.", "q": "My VIP group gets GUARANTEED 3% daily returns with zero risk."},
        {"t": "Pressure to act now.", "q": "Only 20 spots left and the offer ends tonight!"},
        {"t": "Payment in crypto or gift cards, which can't be reversed.", "q": "Send your deposit in USDT or gift cards and I'll set up your account."},
        {"t": "Withdrawals locked behind a \u201ctier\u201d: often a trick to demand more money.", "q": "Withdrawals open after 90 days once you unlock your profit tier."},
        {"t": "Secret, \u201cinsider-only\u201d access with no regulated exchange.", "q": "This is private and insider-only, not available on any exchange."},
        {"t": "Unbelievable personal results used as proof.", "q": "I turned $500 into $12,000 in 3 weeks with my AI trading bot!!"}],
      "questions": ["Is this person registered? Look them up on FINRA BrokerCheck.", "Can I see an official document (prospectus) filed with the SEC?"],
      "missing": ["What you would actually own.", "Any fees.", "How the value is calculated.", "Any risks.", "Who regulates the seller."]
    }
  },
]


def _norm(s):
    s = s.replace("\u2019", "'").replace("\u2018", "'").replace("\u201c", '"').replace("\u201d", '"')
    return re.sub(r"\s+", " ", s).strip().lower()


def check():
    """Fail loudly if any receipt is not word-for-word in its document."""
    for smp in SAMPLES:
        doc, lab = _norm(smp["doc"]), smp["label"]
        quotes = []
        for sec in ("owns", "pricing", "risks", "flags"):
            quotes += [i["q"] for i in lab[sec]]
        quotes += [i["q"] for i in lab["access"]["items"]]
        f = lab["fees"]
        quotes += [i["q"] for i in f["yearly"]]
        for k in ("performance", "upfront", "exit"):
            if f[k]:
                quotes.append(f[k]["q"])
        for q in quotes:
            assert _norm(q) in doc, f"[{smp['key']}] receipt not in document: {q}"
    return True


check()
