"""Render the Flask page and inline its CSS/JS into dist/blackstone-bridge.html,
a single file you can open, email, or host anywhere (no server needed)."""
from pathlib import Path
from app import app

ROOT = Path(__file__).parent
html = app.test_client().get("/").get_data(as_text=True)
css = (ROOT / "static" / "style.css").read_text(encoding="utf-8")
js = (ROOT / "static" / "app.js").read_text(encoding="utf-8")

html = html.replace('<link rel="stylesheet" href="/static/style.css">', "<style>\n" + css + "\n</style>")
html = html.replace('<script src="/static/app.js"></script>', "<script>\n" + js + "\n</script>")
html = html.replace('<script src="/static/insights.js"></script>', "<script>\n" + (ROOT / "static" / "insights.js").read_text(encoding="utf-8") + "\n</script>")
html = html.replace('<script src="/static/labels.js"></script>', "<script>\n" + (ROOT / "static" / "labels.js").read_text(encoding="utf-8") + "\n</script>")
assert "/static/" not in html, "an asset was not inlined"

out = ROOT / "dist" / "blackstone-bridge.html"
out.parent.mkdir(exist_ok=True)
out.write_text(html, encoding="utf-8")
print(f"Wrote {out} ({out.stat().st_size // 1024} KB)")
