"""
Blackstone Bridge — Education, not manipulation.

All words, numbers and chat answers live in CONTENT below, so the team can
edit copy without touching HTML or JavaScript. The page is a single
template (templates/index.html) with tab-style sections switched by the URL
hash (#start, #learn, #scams, #numbers, #access, #profile).

Run:   pip install -r requirements.txt && python app.py
Build a single self-contained HTML file for sharing/demo:   python build.py
"""
import json
from pathlib import Path

from flask import Flask, render_template

from labels_data import SAMPLES as LABEL_SAMPLES

app = Flask(__name__)

FTC_SOCIAL_URL = (
    "https://www.ftc.gov/news-events/news/press-releases/2026/04/"
    "new-ftc-data-show-people-have-lost-billions-social-media-scams"
)
BROKERCHECK_URL = "https://brokercheck.finra.org"

# ---------------------------------------------------------------- MARKET DATA
# Annual total returns 1928-2025, from Aswath Damodaran, NYU Stern,
# "Historical Returns on Stocks, Bonds and Bills" (updated January 5, 2026).
# Refresh each January: re-download the table and rebuild data/market.json.
MARKET = json.loads((Path(__file__).parent / "data" / "market.json").read_text())
MARKET_SOURCE = {
    "name": "NYU Stern (Prof. Aswath Damodaran), Historical Returns on Stocks, Bonds and Bills, 1928\u20132025",
    "url": "https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/histretSP.html",
}

# What each investment is, in plain words. `series` points at MARKET data;
# None means there is no public year-by-year price history for it.
ASSETS = [
    {"key": "sp500", "series": "sp500", "name": "U.S. large-company stocks", "short": "Large stocks",
     "example": "an S&P 500 index fund", "group": "Stocks", "color": "#5B3FE0",
     "owns": "Shares of the 500 largest U.S. companies, with dividends reinvested.",
     "access": "Any business day", "days": 2},
    {"key": "small", "series": "small", "name": "U.S. small-company stocks", "short": "Small stocks",
     "example": "a small-cap stock fund", "group": "Stocks", "color": "#A594F9",
     "owns": "Shares of the smallest 10% of U.S. listed companies.",
     "access": "Any business day", "days": 2},
    {"key": "tbond", "series": "tbond", "name": "U.S. Treasury bonds (10-year)", "short": "Treasury bonds",
     "example": "a Treasury bond fund", "group": "Bonds", "color": "#0B7A55",
     "owns": "Loans to the U.S. government, repaid over 10 years with interest.",
     "access": "Any business day", "days": 2},
    {"key": "corp", "series": "corp", "name": "Corporate bonds", "short": "Corporate bonds",
     "example": "a corporate bond fund", "group": "Bonds", "color": "#3CC08A",
     "owns": "Loans to mid-grade (Baa-rated) U.S. companies.",
     "access": "Any business day", "days": 2},
    {"key": "cash", "series": "cash", "name": "Cash and money market", "short": "Cash",
     "example": "a money market fund or Treasury bills", "group": "Cash", "color": "#8E8AA8",
     "owns": "Very short loans to the U.S. government (3-month Treasury bills).",
     "access": "Same day to a few days", "days": 1},
    {"key": "gold", "series": "gold", "name": "Gold", "short": "Gold",
     "example": "a gold fund", "group": "Other", "color": "#E0A100",
     "owns": "Gold bullion. It pays no interest or dividends.",
     "access": "Any business day (through a fund)", "days": 2},
    {"key": "home", "series": "home", "name": "U.S. home prices", "short": "Home prices",
     "example": "a home or rental property", "group": "Other", "color": "#D6336C",
     "owns": "Change in U.S. home prices only (not rent, repairs or taxes).",
     "access": "Weeks to months to sell", "days": 60},
    {"key": "private_re", "series": None, "name": "Private real estate fund", "short": "Private real estate",
     "example": "a non-traded REIT such as BREIT", "group": "Private markets", "color": "#1C1640",
     "owns": "Part-ownership of apartments, warehouses and other buildings, managed by a firm like Blackstone.",
     "access": "Monthly, up to limits (e.g. 2% of the fund a month, 5% a quarter)", "days": 30},
]

# What is happening now. Update when new figures are released.
SNAPSHOT = [
    {"label": "Fed interest rate", "value": "3.75\u20134.00%",
     "when": "Raised Sept. 16, 2026, the first increase since 2023",
     "means": "Cash and new bonds pay more. Existing bonds usually lose value when rates rise, as in 2022.",
     "src": ["Federal Reserve", "https://www.federalreserve.gov/newsevents/pressreleases/monetary20260916a1.htm"]},
    {"label": "Inflation", "value": "3.4%",
     "when": "Prices over the 12 months to August 2026",
     "means": "Money in savings loses buying power if it earns less than 3.4% a year.",
     "src": ["U.S. Bureau of Labor Statistics", "https://www.bls.gov/news.release/cpi.nr0.htm"]},
    {"label": "Large U.S. stocks in 2025", "value": "+17.8%",
     "when": "Third strong year in a row, after +26.1% and +24.9%",
     "means": "Strong runs don't predict the next year. Stocks fell 18% in 2022.",
     "src": ["NYU Stern", MARKET_SOURCE["url"]]},
]

CONTENT = {
    "brand": "Blackstone Bridge",
    "slogan": "Education, not manipulation.",

    # ------------------------------------------------------------------ START
    "hero_title": "Read the fine print in 30 seconds.",
    "hero_sub": (
        "Paste any fund document, fact sheet or investment pitch. Bridge turns it into a one-page "
        "label: what you own, what it costs in dollars, when you can get your money out, and what "
        "could go wrong. Every line links to the exact sentence it came from."
    ),
    "trust_row": ["Every line links to its source", "Fees in dollars, on your amount", "We never ask for your password"],
    "pillars": [
        {"name": "Transparency", "color": "blue",
         "body": "Every fee in dollars. Every number links to its public source. You always see when you can take your money out."},
        {"name": "Control", "color": "green",
         "body": "Start with $5. Change or stop any time. No countdown timers, no pressure, no \u201climited-time\u201d offers."},
        {"name": "Connection", "color": "violet",
         "body": "Ask anything in your own words, any time. Reach a real, licensed human in one tap."},
        {"name": "No manipulation", "color": "sun",
         "body": "We never ask for your password, never sell your data, and never tell you what to buy."},
    ],
    "start_choices": [
        {"q": "Someone offered me an investment. Is it legit?",
         "sub": "Paste the post or document and see its red flags, with receipts.",
         "href": "#label/pitch"},
        {"q": "What am I really paying?",
         "sub": "See any fund's fees in dollars on your amount, over 10 years.",
         "href": "#label/breit"},
        {"q": "Can I get my money back if I need it?",
         "sub": "Compare how quickly different investments turn back into cash.",
         "href": "#access"},
        {"q": "I've never invested. Where do I start?",
         "sub": "Five short lessons, about four minutes each. No jargon.",
         "href": "#learn"},
        {"q": "I want to practice first.",
         "sub": "Open a demo account and see how a starter portfolio would have done.",
         "href": "#profile"},
    ],
    "alert": {
        "date": "April 2026",
        "source": "U.S. Federal Trade Commission",
        "body": (
            "In 2025, nearly 30% of people who reported losing money to a scam said it started "
            "on social media, and fake investment offers there cost more than any other kind. "
            "If a post, video or direct message asks you to invest, stop and look up the seller "
            "on FINRA BrokerCheck first."
        ),
        "url": FTC_SOCIAL_URL,
    },

    # ------------------------------------------------------------------ LEARN
    # Lessons are a real sequence, so they are numbered.
    "lessons": [
        {
            "slug": "what-is-a-stock",
            "title": "What is a stock?",
            "minutes": 4,
            "body": [
                "A stock (also called a share) is a small piece of ownership in a company. "
                "If a company is split into one million pieces and you buy one, you own "
                "one-millionth of it.",
                "When the company does well, your piece can become worth more. When it "
                "struggles, your piece can be worth less. Nobody can honestly promise "
                "which way it will go.",
            ],
            "example": (
                "Picture a neighborhood bakery split into 100 shares. Buy 5 and you own 5% "
                "of the bakery. If it opens a second shop and earns more, your 5% is worth "
                "more. If a new bakery opens across the road and takes customers, your 5% "
                "may be worth less."
            ),
            "terms": [
                ["Share", "One piece of ownership in a company."],
                ["Dividend", "Part of the profits that some companies pay out to their owners."],
                ["Stock exchange", "A regulated marketplace for buying and selling shares, "
                                   "such as the New York Stock Exchange or Nasdaq."],
            ],
            "quiz": {
                "q": "You own shares in a company that has a bad year. What most likely happens?",
                "options": [
                    "Your shares are worth less, at least for now.",
                    "The company must pay you back in full.",
                    "Nothing changes, because share prices are guaranteed.",
                ],
                "answer": 0,
                "right": "Correct. Owning part of a company means sharing in its bad years as well as its good ones.",
                "wrong": "Not quite. Shares are not a loan and carry no guarantee. When a company struggles, its shares usually fall in value.",
            },
        },
        {
            "slug": "what-is-a-fund",
            "title": "What is a fund?",
            "minutes": 4,
            "body": [
                "A fund pools money from many people and buys many investments at once. "
                "Instead of betting on one bakery, you own a small slice of hundreds of "
                "businesses.",
                "An index fund simply copies a whole list of companies, like the largest "
                "companies on an exchange, which keeps its running costs low.",
            ],
            "example": (
                "A fund works a little like an office lottery pool, minus the luck: many people "
                "put money into one pot. The difference is that a fund invests the pot in real "
                "businesses, the value can go up or down, and regulators watch the people who run it."
            ),
            "terms": [
                ["Diversification", "Spreading money across many investments so one failure cannot sink you."],
                ["Index fund", "A fund that copies a published list of companies instead of picking favorites."],
                ["Fund manager", "The licensed firm that makes the fund's investment decisions."],
            ],
            "quiz": {
                "q": "Why do many people choose a fund instead of a single stock?",
                "options": [
                    "It spreads the risk across many companies.",
                    "Funds can never lose money.",
                    "Funds pay a fixed return every month.",
                ],
                "answer": 0,
                "right": "Correct. Owning many companies means one bad result has a smaller effect on your money.",
                "wrong": "Not quite. Funds can still lose value. Their main benefit is spreading risk across many investments.",
            },
        },
        {
            "slug": "risk-and-time",
            "title": "Risk and time",
            "minutes": 3,
            "body": [
                "Investments that can grow more usually swing up and down more along the way. "
                "Over a few months, prices can jump around a lot. Over many years, broad "
                "markets have historically grown, but the past does not promise the future.",
                "A common rule of thumb is that money you may need within a few years is often "
                "kept somewhere steadier, such as a savings account.",
            ],
            "example": (
                "Money for next year's school fees and money for retirement in 20 years are "
                "different kinds of money. The first cannot wait out a bad year. The second can."
            ),
            "terms": [
                ["Volatility", "How much and how quickly a price moves up and down."],
                ["Time horizon", "How long until you will need the money."],
                ["Guaranteed return", "Outside of insured savings, this phrase is a warning sign."],
            ],
            "quiz": {
                "q": "Someone promises you \u201chigh returns with no risk\u201d. What does that tell you?",
                "options": [
                    "It is a warning sign. Higher returns always come with risk.",
                    "It is a rare, lucky opportunity.",
                    "It must be safe if a friend recommended it.",
                ],
                "answer": 0,
                "right": "Correct. High returns and no risk do not go together. This promise is the most common sign of a scam.",
                "wrong": "Be careful here. Real investments that can earn more can also lose more. \u201cNo risk\u201d is a classic scam promise.",
            },
        },
        {
            "slug": "public-vs-private",
            "title": "Public and private markets",
            "minutes": 5,
            "body": [
                "Public markets are where anyone can buy shares of listed companies, on any "
                "business day, at a price everyone can see.",
                "Private markets are investments that do not trade on an exchange: apartment "
                "buildings, warehouses, power and data infrastructure, and privately owned "
                "companies. Firms like Blackstone have long managed these for pension funds, "
                "and now offer some of them to individual investors through financial advisers.",
                "The trade-off is simple to say: access to investments once reserved for large "
                "institutions, in exchange for potentially higher fees, prices that update less "
                "often, more complexity, and limits on how quickly you can take money out.",
            ],
            "example": (
                "Selling a share of a listed company is like selling a phone: there are always "
                "buyers, and the price is posted. Selling your part of an apartment building is "
                "more like selling a house: it takes time, and the price is an estimate until "
                "a buyer agrees."
            ),
            "terms": [
                ["Liquidity", "How quickly you can turn an investment back into cash without losing value."],
                ["Net asset value (NAV)", "The estimated value of everything a fund owns, divided by its shares."],
                ["Alternative assets", "Investments other than listed stocks, bonds and cash."],
            ],
            "quiz": {
                "q": "What is the main trade-off with private-market funds?",
                "options": [
                    "Less access to your cash, in exchange for different kinds of investments.",
                    "They are guaranteed by the government.",
                    "You can sell them instantly at any time.",
                ],
                "answer": 0,
                "right": "Correct. Private-market funds usually limit withdrawals. That is why understanding the rules before you invest matters.",
                "wrong": "Not quite. Private-market funds are not guaranteed, and withdrawals are usually limited to set windows and amounts.",
            },
        },
        {
            "slug": "fees-in-dollars",
            "title": "Fees, in dollars",
            "minutes": 3,
            "calculator": True,
            "body": [
                "A yearly fee of 1% sounds small. It adds up because it is taken from your whole "
                "balance every year, including from growth you earned in earlier years.",
                "Always ask what a fee costs in dollars, not only in percent. Use the calculator "
                "below to see it for yourself.",
            ],
            "example": None,
            "terms": [
                ["Management fee", "A yearly charge, as a percent of your balance, for running the fund."],
                ["Expense ratio", "All of a fund's yearly running costs, as a percent of your balance."],
            ],
            "quiz": {
                "q": "Two funds earn the same before fees. One charges 0.2% a year and the other 1.5%. After 20 years, which leaves you more money?",
                "options": [
                    "The 0.2% fund, by a noticeable amount.",
                    "They end up about the same.",
                    "The 1.5% fund, because higher fees mean better management.",
                ],
                "answer": 0,
                "right": "Correct. Small yearly differences in fees grow into large differences in dollars over time.",
                "wrong": "Try the calculator above. A higher fee does not promise better results, and the gap grows every year.",
            },
        },
    ],

    # ------------------------------------------------------------------ SCAMS
    "red_flags": [
        "They promise high returns with little or no risk.",
        "You earn more by bringing in friends or family.",
        "They push you to decide today, before you can ask anyone.",
        "They contacted you first, by text, WhatsApp, social media or a call.",
        "They want payment in crypto, gift cards, or to a personal account.",
        "They are not registered with the SEC or FINRA, or will not say.",
        "You must pay a fee before you can withdraw your own money.",
        "A celebrity, influencer or \u201cfriend of a friend\u201d vouches for it.",
    ],
    "history": [
        {"when": "2008",
         "what": "Bernard Madoff's Ponzi scheme collapsed, with about $65 billion in paper losses. "
                 "His firm was registered with the SEC, and clients received official-looking "
                 "statements for years."},
        {"when": "2022",
         "what": "Crypto exchange FTX collapsed. Customers could not withdraw their money, and "
                 "its founder was convicted of fraud in 2023."},
        {"when": "2025",
         "what": "Americans reported losing $7.9 billion to investment scams, about half of all "
                 "reported fraud losses, often after being contacted on social media."},
    ],

    # ---------------------------------------------------------------- NUMBERS
    "numbers": {
        # Gallup, combined April 2024 + April 2025 surveys
        "own_by_age": [["Age 18\u201329", 44], ["Age 30\u201349", 65], ["Age 50\u201364", 72], ["Age 65+", 61]],
        "own_by_edu": [["College graduate", 84], ["Some college", 60], ["High school or less", 42]],
        # FTC Consumer Sentinel Data Book 2024
        "fraud_rate": [["Age 20\u201329", 44], ["Age 70\u201379", 24], ["Age 80+", 21]],
        "fraud_median": [["Age 20\u201329", 417], ["Age 70\u201379", 1000], ["Age 80+", 1650]],
        # FTC reported losses to investment scams, US$ billions
        "invest_scam_trend": [["2022", 3.8], ["2023", 4.6], ["2024", 5.7], ["2025", 7.9]],
    },
    "sources": [
        [MARKET_SOURCE["name"], MARKET_SOURCE["url"]],
        ["Federal Reserve FOMC implementation note, September 16, 2026",
         "https://www.federalreserve.gov/newsevents/pressreleases/monetary20260916a1.htm"],
        ["U.S. Bureau of Labor Statistics, Consumer Price Index, August 2026",
         "https://www.bls.gov/news.release/cpi.nr0.htm"],
        ["Gallup, What Percentage of Americans Own Stock? (by age and education, 2024\u201325 surveys)",
         "https://news.gallup.com/poll/266807/percentage-americans-owns-stock.aspx"],
        ["The Motley Fool, Gallup April 2026 stock ownership (58%)",
         "https://www.fool.com/research/how-many-americans-own-stock/"],
        ["FTC, Consumer Sentinel Network Data Book 2024 (fraud by age)",
         "https://www.ftc.gov/system/files/ftc_gov/pdf/csn-annual-data-book-2024.pdf"],
        ["FTC, Consumer Sentinel Network Data Book 2022 (2022 investment scam losses)",
         "https://www.ftc.gov/system/files/ftc_gov/pdf/CSN-Data-Book-2022.pdf"],
        ["FTC testimony to the Joint Economic Committee, March 2026 (2025 losses)",
         "https://www.ftc.gov/system/files/ftc_gov/pdf/ftc-testimony-jec-hearing-on-the-rising-scam-economy.pdf"],
        ["FTC, social media scams data, April 2026",
         FTC_SOCIAL_URL],
        ["The DI Wire: BREIT fulfills 100% of repurchase requests, March 2024",
         "https://thediwire.com/?p=43137"],
        ["Bisnow: BREIT fulfills all redemption requests for first time since 2022",
         "https://www.bisnow.com/national/news/capital-markets/breit-fulfills-all-redemption-requests-for-first-time-in-more-than-a-year-123143"],
    ],

    # ----------------------------------------------------------------- ACCESS
    "ladder": [
        {"name": "Savings account", "speed": "Same day, usually",
         "note": "Your balance does not fall when markets fall.", "level": 1},
        {"name": "Listed stocks and index funds", "speed": "Sell any business day; cash in a day or two",
         "note": "But the price may be lower than what you paid.", "level": 2},
        {"name": "Non-traded real estate and interval funds", "speed": "Monthly or quarterly, up to a limit",
         "note": "If many people ask at once, each person may get only part of their request.", "level": 3},
        {"name": "Private equity funds", "speed": "Often locked for 10 years or more",
         "note": "Money is returned as the fund sells what it owns.", "level": 4},
    ],
    "breit_story": [
        {"when": "Nov 2022",
         "what": "Withdrawal requests to Blackstone's non-traded real estate fund (BREIT) passed its "
                 "limits of 2% of the fund per month and 5% per quarter, so each investor received "
                 "part of their request."},
        {"when": "Jan 2023",
         "what": "Requests peaked at about $5.3 billion in a single month."},
        {"when": "Dec 2023",
         "what": "About half of that month's requests were paid ($569 million of $1.1 billion); "
                 "the rest waited for the next window."},
        {"when": "Feb 2024",
         "what": "The fund paid 100% of requests again, after 15 months of limits and more than "
                 "$15 billion returned to investors along the way."},
    ],
    "adviser_questions": [
        "How and when can I take money out, and what are the limits?",
        "What will I pay each year, in dollars, not only in percent?",
        "How is the value of this investment worked out, and how often?",
        "Who holds my money, and who checks them?",
        "Are you licensed, and how are you paid for recommending this?",
    ],

    # ---------------------------------------------------------------- PROFILE
    # Sample data for the demo profile. Replace with real account data later.
    "profile": {
        "member_since": "Member since 2025",
        # Starting holdings for the demo account: [asset key, dollars].
        "demo_holdings": [["cash", 2500], ["sp500", 1200], ["small", 300]],
        "presets": [
            {"name": "Just starting ($500)", "holdings": [["sp500", 500]]},
            {"name": "Emergency fund first", "holdings": [["cash", 3000], ["sp500", 500]]},
            {"name": "$25 a week for 3 years", "holdings": [["sp500", 2600], ["tbond", 800], ["cash", 1000]]},
            {"name": "Curious about private markets", "holdings": [["sp500", 6000], ["tbond", 2000], ["private_re", 2500], ["cash", 1500]]},
        ],
        "adviser": {"name": "Andre Walters", "role": "Licensed adviser (sample)", "initials": "AW"},
    },

    # ------------------------------------------------------------------- CHAT
    # A rule-based guide: predictable, never invents facts, never sells.
    # Each topic: keywords to match, a plain answer, optional buttons.
    "chat": {
        "hello": (
            "Hi, I'm the Bridge guide. I explain money in plain language. "
            "I don't sell anything, and I will never ask for your password, PIN or one-time code."
        ),
        "chips": ["Explain my portfolio", "Stocks or bonds: what's the difference?",
                  "What do rising rates mean for me?", "Can I get my money out?",
                  "Is this a scam?", "Talk to a person"],
        "topics": [
            {"keys": ["hello", "hi", "hey", "good morning", "good evening"],
             "reply": "Hello! What would you like to understand today? You can type a question or tap one of the buttons."},
            {"keys": ["my portfolio", "what do i own", "what i own", "explain my", "my mix", "my money"],
             "reply": "Your portfolio page shows what you own, how that mix has really done over the last 5 to 30 years, how much you could reach within a week, and your fees in dollars.",
             "go": [["Open my portfolio", "#profile"]]},
            {"keys": ["compare", "versus", "vs", "better investment", "which is better", "difference"],
             "reply": "The Research page lets you compare up to three investments side by side using real yearly returns from 1928 to 2025, and see what adding one would do to your portfolio.",
             "go": [["Compare investments", "#research"]]},
            {"keys": ["rate", "rates", "fed", "inflation", "interest"],
             "reply": "The Fed raised its rate to 3.75\u20134.00% on Sept. 16, 2026, and inflation was 3.4% in August. Rising rates usually help cash and new bonds, but lower the value of bonds you already own, as in 2022.",
             "go": [["See what's happening now", "#start"], ["Compare bonds and cash", "#research"]]},
            {"keys": ["password", "pin", "otp", "one-time", "code", "verify my account", "login link", "log in link"],
             "reply": "Never share your password, PIN or one-time code with anyone, including us. Blackstone Bridge will never text or email you a link to log in. If you received one, don't tap it.",
             "go": [["Practice spotting a fake message", "#scams/phishing"]]},
            {"keys": ["text", "sms", "whatsapp", "email", "link", "phishing", "message"],
             "reply": "Messages that rush you, come from unknown senders, or contain links to \u201cverify\u201d your account are the most common trick. Open your app or call the number on your card instead of using the link.",
             "go": [["Try the fake-message practice", "#scams/phishing"]]},
            {"keys": ["pyramid", "ponzi", "recruit", "bring in friends", "network marketing", "mlm"],
             "reply": "In a pyramid or Ponzi scheme, returns come from new members' money rather than a real business. They always collapse, because they need more and more people. The simulator shows how fast.",
             "go": [["See the pyramid simulator", "#scams/pyramid"]]},
            {"keys": ["scam", "fraud", "legit", "real", "offer", "too good", "trust this", "guaranteed"],
             "reply": "Good instinct to check. Warning signs include promised high returns with no risk, pressure to act fast, payment by crypto or gift cards, and sellers who are not registered with the SEC or FINRA. You can look up any broker or adviser for free on FINRA BrokerCheck.",
             "go": [["Check an offer now", "#scams"]]},
            {"keys": ["withdraw", "money out", "get my money", "locked", "lock up", "liquid", "cash out", "redeem", "redemption", "take out"],
             "reply": "It depends on the investment. Savings are usually same-day. Listed stocks sell any business day. Private-market funds often allow withdrawals only monthly or quarterly, up to a limit, and some lock money for 10 years or more. Always read the withdrawal rules before you invest.",
             "go": [["See how each one works", "#access"]]},
            {"keys": ["fee", "fees", "cost", "charge", "expense"],
             "reply": "Ask for every fee in dollars per year. A 1% yearly fee on $10,000 is about $100 in the first year, and it grows as your balance grows. The calculator shows the 20-year effect.",
             "go": [["Open the fee calculator", "#learn/fees-in-dollars"]]},
            {"keys": ["blackstone", "private market", "private equity", "reit", "breit", "alternative", "institution"],
             "reply": "Blackstone manages private-market investments like real estate, infrastructure and private companies. Individual investors can now reach some of these through advisers. The trade-off: access to institutional investments, in exchange for potentially higher fees, less liquidity and more complexity.",
             "go": [["Learn about private markets", "#learn/public-vs-private"], ["How withdrawals work", "#access"]]},
            {"keys": ["stock", "share", "shares", "equity"],
             "reply": "A stock is a small piece of ownership in a company. If the company grows, your piece can be worth more; if it struggles, it can be worth less. No one can promise which way.",
             "go": [["Take the 4-minute lesson", "#learn/what-is-a-stock"]]},
            {"keys": ["fund", "index", "etf", "mutual", "diversif"],
             "reply": "A fund pools money from many people to buy many investments at once, so one bad company has a smaller effect on you.",
             "go": [["Read the fund lesson", "#learn/what-is-a-fund"]]},
            {"keys": ["risk", "lose", "safe", "safety", "crash"],
             "reply": "Every investment that can grow can also fall. The question is whether you can wait out a bad year. Money you may need soon is often kept somewhere steadier.",
             "go": [["Read about risk and time", "#learn/risk-and-time"]]},
            {"keys": ["start", "begin", "new", "first", "beginner", "don't know", "dont know"],
             "reply": "A good first step is the short lesson on what a stock is, then the one on funds. Each takes about four minutes and ends with one simple question.",
             "go": [["Start lesson 1", "#learn/what-is-a-stock"]]},
            {"keys": ["age", "who invests", "statistic", "data", "numbers", "young", "older"],
             "reply": "In U.S. data, adults aged 50\u201364 are the most likely to own stock, followed by 30\u201349 and 65+. Adults in their twenties report losing money to fraud most often, while people over 70 lose far more each time.",
             "go": [["See the numbers", "#numbers"]]},
            {"keys": ["person", "human", "adviser", "advisor", "call", "talk", "someone", "agent", "representative"],
             "reply": "You can reach a licensed adviser. In this demo, tap below to request a call back. Before you talk to any adviser, you can look them up on FINRA BrokerCheck.",
             "handoff": True},
            {"keys": ["thank", "thanks", "respect", "bless"],
             "reply": "You're welcome. Take your time, and come back whenever you have a question."},
        ],
        "fallback": (
            "I don't have a good answer for that yet, and I'd rather not guess with your money. "
            "Try one of the buttons below, or ask to talk to a person."
        ),
    },
}


@app.context_processor
def inject_content():
    return {"c": CONTENT, "market": MARKET, "assets": ASSETS,
            "snapshot": SNAPSHOT, "market_source": MARKET_SOURCE, "label_samples": LABEL_SAMPLES}


@app.route("/")
def index():
    return render_template("index.html")


if __name__ == "__main__":
    app.run(debug=True)
